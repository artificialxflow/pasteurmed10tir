import { prisma } from '@/lib/prisma';
import { normalizePhoneDigits } from '@/lib/operations/phone';
import { generateCommerceId } from '@/lib/commerce/mappers';
import { loadWalletSettings } from '@/lib/commerce/wallet-service';
import {
  clampLoanMonths,
  computeLoanRepaymentTotal,
  isZeroInterestLoanTerm,
} from '@/lib/membership';
import type {
  InstallmentItemStatus,
  InstallmentPaymentMethod,
  InstallmentSource,
} from '@prisma/client';

/** قسط اول = start + ۱ ماه (پیش‌فرض). طرح‌های موجود را با firstDueOffsetMonths: 0 بازسازی کن. */
export function buildDueDates(
  count: number,
  start = new Date(),
  options?: { firstDueOffsetMonths?: number },
): string[] {
  const dates: string[] = [];
  const cursor = new Date(start);
  cursor.setMonth(cursor.getMonth() + (options?.firstDueOffsetMonths ?? 1));
  for (let i = 0; i < count; i += 1) {
    dates.push(cursor.toISOString());
    cursor.setMonth(cursor.getMonth() + 1);
  }
  return dates;
}

/** Split total across N installments; remainder on the last. */
export function splitInstallmentAmounts(total: number, count: number): number[] {
  const n = Math.max(1, count);
  const base = Math.floor(total / n);
  const amounts = Array.from({ length: n }, () => base);
  const remainder = total - base * n;
  amounts[n - 1] += remainder;
  return amounts;
}

function startOfToday(): Date {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
}

export function deriveItemStatus(input: {
  dueDate: Date;
  amount: number;
  paidAmount: number;
}): InstallmentItemStatus {
  if (input.paidAmount >= input.amount) return 'paid';
  if (input.paidAmount > 0) return 'partial';
  const due = new Date(input.dueDate);
  due.setHours(0, 0, 0, 0);
  if (due < startOfToday()) return 'overdue';
  if (due.getTime() === startOfToday().getTime()) return 'due';
  return 'pending';
}

export function buildScheduleCreateData(input: {
  totalAmount: number;
  installmentCount: number;
  dueDates: string[];
}) {
  const count = Math.max(1, input.installmentCount);
  const amounts = splitInstallmentAmounts(input.totalAmount, count);
  const dates =
    input.dueDates.length >= count
      ? input.dueDates.slice(0, count)
      : buildDueDates(count);

  return amounts.map((amount, i) => {
    const dueDate = new Date(dates[i] || dates[dates.length - 1] || new Date().toISOString());
    return {
      id: generateCommerceId(),
      index: i + 1,
      dueDate,
      amount,
      paidAmount: 0,
      status: deriveItemStatus({ dueDate, amount, paidAmount: 0 }),
    };
  });
}

/** Allocate plan.paidAmount onto earliest schedule items (for backfill). */
export function allocatePaidAcrossItems(
  amounts: number[],
  paidTotal: number,
): number[] {
  let remaining = Math.max(0, paidTotal);
  return amounts.map((amount) => {
    const paid = Math.min(amount, remaining);
    remaining -= paid;
    return paid;
  });
}

async function ensureScheduleForPlan(planId: string) {
  const plan = await prisma.installmentPlan.findUnique({
    where: { id: planId },
    include: { scheduleItems: true },
  });
  if (!plan) return null;
  if (plan.scheduleItems.length > 0) return plan;

  const amounts = splitInstallmentAmounts(plan.totalAmount, plan.installmentCount);
  const paidParts = allocatePaidAcrossItems(amounts, plan.paidAmount);
  const dates =
    plan.dueDates.length >= plan.installmentCount
      ? plan.dueDates
      : buildDueDates(plan.installmentCount, plan.createdAt, { firstDueOffsetMonths: 0 });

  await prisma.installmentScheduleItem.createMany({
    data: amounts.map((amount, i) => {
      const dueDate = new Date(dates[i] || plan.createdAt);
      const paidAmount = paidParts[i] || 0;
      return {
        id: generateCommerceId(),
        planId: plan.id,
        index: i + 1,
        dueDate,
        amount,
        paidAmount,
        status: deriveItemStatus({ dueDate, amount, paidAmount }),
      };
    }),
  });

  return prisma.installmentPlan.findUnique({
    where: { id: planId },
    include: {
      scheduleItems: { orderBy: { index: 'asc' } },
      payments: { orderBy: { createdAt: 'desc' } },
    },
  });
}

export async function createCreditInstallmentPlan(input: {
  phone?: string | null;
  patientName?: string;
  ceilingAmount: number;
  label?: string;
  linkedRequestId?: string;
  installmentCount?: number;
}) {
  const phone = normalizePhoneDigits(input.phone || '');
  if (!phone) return null;
  const total = Math.max(0, Number(input.ceilingAmount || 0));
  if (!total) return null;

  const settings = await loadWalletSettings();
  const min = settings.installmentMin || 1;
  const max = settings.installmentMax || 6;
  const requested = Number(input.installmentCount);
  const count = Number.isInteger(requested) && requested >= min && requested <= max ? requested : max;
  const dueDates = buildDueDates(count);

  return prisma.installmentPlan.create({
    data: {
      id: generateCommerceId(),
      phone,
      patientName: input.patientName || null,
      source: 'credit',
      title: input.label || `اقساط اعتباری ${total.toLocaleString('fa-IR')} تومان`,
      totalAmount: total,
      paidAmount: 0,
      installmentCount: count,
      dueDates,
      status: 'active',
      linkedRequestId: input.linkedRequestId || null,
      scheduleItems: { create: buildScheduleCreateData({ totalAmount: total, installmentCount: count, dueDates }) },
    },
    include: { scheduleItems: { orderBy: { index: 'asc' } }, payments: true },
  });
}

export async function createFacilityInstallmentPlan(input: {
  phone?: string | null;
  patientName?: string;
  amount: number;
  linkedRequestId?: string;
  title?: string;
}) {
  const phone = normalizePhoneDigits(input.phone || '');
  if (!phone) return null;
  const total = Math.max(0, Number(input.amount || 0));
  if (!total) return null;
  const count = 6;
  const dueDates = buildDueDates(count);

  return prisma.installmentPlan.create({
    data: {
      id: generateCommerceId(),
      phone,
      patientName: input.patientName || null,
      source: 'facility',
      title: input.title || `اقساط تسهیلات ${total.toLocaleString('fa-IR')} تومان`,
      totalAmount: total,
      paidAmount: 0,
      installmentCount: count,
      dueDates,
      status: 'active',
      linkedRequestId: input.linkedRequestId || null,
      scheduleItems: { create: buildScheduleCreateData({ totalAmount: total, installmentCount: count, dueDates }) },
    },
    include: { scheduleItems: { orderBy: { index: 'asc' } }, payments: true },
  });
}

/** Medical/membership loan after admin approve — 0% for 1–3 months, else +12%. */
export async function createLoanInstallmentPlan(input: {
  phone?: string | null;
  patientName?: string;
  amount: number;
  months?: number;
  linkedRequestId?: string;
  title?: string;
}) {
  const phone = normalizePhoneDigits(input.phone || '');
  if (!phone) return null;
  const principal = Math.max(0, Number(input.amount || 0));
  if (!principal) return null;
  const months = clampLoanMonths(input.months, 12);
  const total = computeLoanRepaymentTotal(principal, months);
  const dueDates = buildDueDates(months);
  const rateNote = isZeroInterestLoanTerm(months)
    ? 'سود ۰٪'
    : `سود ۱۲٪ سالانه × ${(months / 12).toLocaleString('fa-IR')} سال`;

  return prisma.installmentPlan.create({
    data: {
      id: generateCommerceId(),
      phone,
      patientName: input.patientName || null,
      source: 'loan',
      title:
        input.title ||
        `اقساط وام درمانی ${total.toLocaleString('fa-IR')} تومان (${months} ماه، ${rateNote})`,
      totalAmount: total,
      paidAmount: 0,
      installmentCount: months,
      dueDates,
      status: 'active',
      linkedRequestId: input.linkedRequestId || null,
      scheduleItems: { create: buildScheduleCreateData({ totalAmount: total, installmentCount: months, dueDates }) },
    },
    include: { scheduleItems: { orderBy: { index: 'asc' } }, payments: true },
  });
}

export async function hideMembershipInstallmentPlans(phone?: string | null) {
  const key = phone ? normalizePhoneDigits(phone) : null;
  await prisma.installmentPlan.updateMany({
    where: {
      deletedAt: null,
      source: 'membership',
      ...(key ? { phone: key } : {}),
    },
    data: { status: 'hidden' },
  });
}

export async function listVisibleInstallments(phone?: string | null) {
  const key = phone ? normalizePhoneDigits(phone) : undefined;
  const rows = await prisma.installmentPlan.findMany({
    where: {
      deletedAt: null,
      status: { not: 'hidden' },
      source: { not: 'membership' },
      ...(key ? { phone: key } : {}),
    },
    include: {
      scheduleItems: { orderBy: { index: 'asc' } },
      payments: { orderBy: { createdAt: 'desc' } },
    },
    orderBy: { createdAt: 'desc' },
  });

  const out = [];
  for (const row of rows) {
    if (row.scheduleItems.length === 0) {
      const healed = await ensureScheduleForPlan(row.id);
      if (healed) out.push(healed);
      else out.push(row);
    } else {
      // Refresh derived statuses (overdue) without heavy writes every time —
      // only update if stale overdue/pending mismatch.
      let dirty = false;
      for (const item of row.scheduleItems) {
        const next = deriveItemStatus(item);
        if (next !== item.status && item.status !== 'paid') {
          dirty = true;
          await prisma.installmentScheduleItem.update({
            where: { id: item.id },
            data: { status: next },
          });
        }
      }
      if (dirty) {
        const refreshed = await prisma.installmentPlan.findUnique({
          where: { id: row.id },
          include: {
            scheduleItems: { orderBy: { index: 'asc' } },
            payments: { orderBy: { createdAt: 'desc' } },
          },
        });
        out.push(refreshed || row);
      } else {
        out.push(row);
      }
    }
  }
  return out;
}

export async function applyInstallmentPayment(input: {
  planId: string;
  scheduleItemId: string;
  amount: number;
  method: InstallmentPaymentMethod;
  trackId?: string | null;
  note?: string | null;
  phone?: string | null;
}) {
  const plan = await prisma.installmentPlan.findUnique({
    where: { id: input.planId },
    include: { scheduleItems: true },
  });
  if (!plan) throw new Error('طرح اقساط یافت نشد.');
  if (input.phone) {
    const phone = normalizePhoneDigits(input.phone);
    if (plan.phone !== phone) throw new Error('دسترسی به این طرح مجاز نیست.');
  }

  const item = plan.scheduleItems.find((s) => s.id === input.scheduleItemId);
  if (!item) throw new Error('قسط یافت نشد.');
  if (item.status === 'paid' || item.paidAmount >= item.amount) {
    throw new Error('این قسط قبلاً پرداخت شده است.');
  }

  const due = item.amount - item.paidAmount;
  const amount = Math.round(Number(input.amount));
  if (amount !== due) {
    throw new Error(`مبلغ باید دقیقاً ${due.toLocaleString('fa-IR')} تومان باشد.`);
  }

  const paymentId = generateCommerceId();
  const paidAt = new Date();

  await prisma.$transaction(async (tx) => {
    await tx.installmentPayment.create({
      data: {
        id: paymentId,
        planId: plan.id,
        scheduleItemId: item.id,
        amount,
        method: input.method,
        status: 'completed',
        trackId: input.trackId || null,
        note: input.note || null,
        paidAt,
      },
    });

    const newPaid = item.paidAmount + amount;
    await tx.installmentScheduleItem.update({
      where: { id: item.id },
      data: {
        paidAmount: newPaid,
        status: deriveItemStatus({
          dueDate: item.dueDate,
          amount: item.amount,
          paidAmount: newPaid,
        }),
      },
    });

    const planPaid = plan.paidAmount + amount;
    const allItems = await tx.installmentScheduleItem.findMany({ where: { planId: plan.id } });
    const allPaid = allItems.every((s) =>
      s.id === item.id ? newPaid >= s.amount : s.paidAmount >= s.amount,
    );

    await tx.installmentPlan.update({
      where: { id: plan.id },
      data: {
        paidAmount: planPaid,
        status: allPaid ? 'completed' : plan.status === 'hidden' ? 'hidden' : 'active',
      },
    });
  });

  return prisma.installmentPlan.findUnique({
    where: { id: plan.id },
    include: {
      scheduleItems: { orderBy: { index: 'asc' } },
      payments: { orderBy: { createdAt: 'desc' } },
    },
  });
}

export type InstallmentSourceValue = InstallmentSource;

type ScheduleItemRow = {
  id: string;
  index: number;
  dueDate: Date;
  amount: number;
  paidAmount: number;
  status: InstallmentItemStatus;
};

/** توزیع مجدد مبلغ باقی‌مانده بین اقساط پرداخت‌نشده */
export function redistributeUnpaidAmounts(
  items: ScheduleItemRow[],
  newTotal: number,
): Array<{ id: string; amount: number }> {
  const locked = items.reduce((sum, item) => sum + item.paidAmount, 0);
  let pool = Math.max(0, newTotal - locked);
  const flexible = items.filter((item) => item.paidAmount < item.amount);
  if (flexible.length === 0) return [];

  const oldRemaining = flexible.reduce(
    (sum, item) => sum + (item.amount - item.paidAmount),
    0,
  );

  const updates: Array<{ id: string; amount: number }> = [];
  let assigned = 0;

  flexible.forEach((item, idx) => {
    const oldRem = item.amount - item.paidAmount;
    let newRem: number;
    if (idx === flexible.length - 1) {
      newRem = pool - assigned;
    } else if (oldRemaining > 0) {
      newRem = Math.round(pool * (oldRem / oldRemaining));
    } else {
      newRem = Math.floor(pool / flexible.length);
    }
    assigned += newRem;
    updates.push({ id: item.id, amount: item.paidAmount + Math.max(0, newRem) });
  });

  return updates;
}

async function refreshPlanTotals(planId: string) {
  const items = await prisma.installmentScheduleItem.findMany({
    where: { planId },
    orderBy: { index: 'asc' },
  });
  const paidAmount = items.reduce((sum, item) => sum + item.paidAmount, 0);
  const totalAmount = items.reduce((sum, item) => sum + item.amount, 0);
  const allPaid = items.every((item) => item.paidAmount >= item.amount);

  await prisma.installmentPlan.update({
    where: { id: planId },
    data: {
      totalAmount,
      paidAmount,
      installmentCount: items.length,
      dueDates: items.map((item) => item.dueDate.toISOString()),
      status: allPaid ? 'completed' : 'active',
    },
  });
}

async function logAdminAdjustment(input: {
  planId: string;
  note?: string | null;
  amount?: number;
}) {
  if (!input.note?.trim()) return;
  await prisma.installmentPayment.create({
    data: {
      id: generateCommerceId(),
      planId: input.planId,
      amount: input.amount ?? 0,
      method: 'manual',
      status: 'completed',
      note: `[ویرایش ادمین] ${input.note.trim()}`,
      paidAt: new Date(),
    },
  });
}

export async function updateInstallmentPlanTotal(input: {
  planId: string;
  totalAmount: number;
  note?: string | null;
}) {
  const plan = await prisma.installmentPlan.findUnique({
    where: { id: input.planId },
    include: { scheduleItems: { orderBy: { index: 'asc' } } },
  });
  if (!plan) return null;
  if (plan.scheduleItems.length === 0) {
    throw new Error('برنامه اقساط خالی است.');
  }

  const paidLocked = plan.scheduleItems.reduce((sum, item) => sum + item.paidAmount, 0);
  if (input.totalAmount < paidLocked) {
    throw new Error('مبلغ کل نمی‌تواند کمتر از مجموع پرداخت‌شده باشد.');
  }

  const updates = redistributeUnpaidAmounts(plan.scheduleItems, input.totalAmount);

  await prisma.$transaction(async (tx) => {
    for (const update of updates) {
      const item = plan.scheduleItems.find((s) => s.id === update.id);
      if (!item) continue;
      await tx.installmentScheduleItem.update({
        where: { id: update.id },
        data: {
          amount: update.amount,
          status: deriveItemStatus({
            dueDate: item.dueDate,
            amount: update.amount,
            paidAmount: item.paidAmount,
          }),
        },
      });
    }
    await tx.installmentPlan.update({
      where: { id: plan.id },
      data: { totalAmount: input.totalAmount },
    });
  });

  await logAdminAdjustment({
    planId: plan.id,
    note: input.note,
    amount: input.totalAmount - plan.totalAmount,
  });
  await refreshPlanTotals(plan.id);

  return prisma.installmentPlan.findUnique({
    where: { id: plan.id },
    include: {
      scheduleItems: { orderBy: { index: 'asc' } },
      payments: { orderBy: { createdAt: 'desc' } },
    },
  });
}

export async function updateInstallmentScheduleItemAmount(input: {
  planId: string;
  scheduleItemId: string;
  amount: number;
  note?: string | null;
}) {
  const item = await prisma.installmentScheduleItem.findFirst({
    where: { id: input.scheduleItemId, planId: input.planId },
  });
  if (!item) throw new Error('قسط یافت نشد.');
  if (item.status === 'paid' || item.paidAmount >= item.amount) {
    throw new Error('قسط پرداخت‌شده قابل ویرایش نیست.');
  }
  const amount = Math.round(input.amount);
  if (amount < item.paidAmount) {
    throw new Error('مبلغ قسط نمی‌تواند کمتر از پرداخت‌شده باشد.');
  }

  await prisma.installmentScheduleItem.update({
    where: { id: item.id },
    data: {
      amount,
      status: deriveItemStatus({
        dueDate: item.dueDate,
        amount,
        paidAmount: item.paidAmount,
      }),
    },
  });

  await logAdminAdjustment({
    planId: input.planId,
    note: input.note || `ویرایش قسط ${item.index} به ${amount.toLocaleString('fa-IR')} تومان`,
    amount: amount - item.amount,
  });
  await refreshPlanTotals(input.planId);

  return prisma.installmentPlan.findUnique({
    where: { id: input.planId },
    include: {
      scheduleItems: { orderBy: { index: 'asc' } },
      payments: { orderBy: { createdAt: 'desc' } },
    },
  });
}

export async function addInstallmentScheduleItem(input: {
  planId: string;
  amount?: number;
  dueDate?: string;
  note?: string | null;
}) {
  const plan = await prisma.installmentPlan.findUnique({
    where: { id: input.planId },
    include: { scheduleItems: { orderBy: { index: 'asc' } } },
  });
  if (!plan) return null;

  const lastIndex = plan.scheduleItems.at(-1)?.index ?? 0;
  const dueDate = input.dueDate ? new Date(input.dueDate) : new Date();
  if (Number.isNaN(dueDate.getTime())) throw new Error('تاریخ سررسید نامعتبر است.');

  const remaining = Math.max(0, plan.totalAmount - plan.paidAmount);
  const unpaidCount =
    plan.scheduleItems.filter((item) => item.paidAmount < item.amount).length + 1;
  const defaultAmount = Math.max(0, Math.floor(remaining / Math.max(1, unpaidCount)));
  const amount = Math.round(input.amount ?? defaultAmount);
  if (amount <= 0) throw new Error('مبلغ قسط باید بیشتر از صفر باشد.');

  await prisma.installmentScheduleItem.create({
    data: {
      id: generateCommerceId(),
      planId: plan.id,
      index: lastIndex + 1,
      dueDate,
      amount,
      paidAmount: 0,
      status: deriveItemStatus({ dueDate, amount, paidAmount: 0 }),
    },
  });

  await logAdminAdjustment({
    planId: plan.id,
    note: input.note || `افزودن قسط ${lastIndex + 1}`,
    amount,
  });
  await refreshPlanTotals(plan.id);

  return prisma.installmentPlan.findUnique({
    where: { id: plan.id },
    include: {
      scheduleItems: { orderBy: { index: 'asc' } },
      payments: { orderBy: { createdAt: 'desc' } },
    },
  });
}

export async function removeInstallmentScheduleItem(input: {
  planId: string;
  scheduleItemId: string;
  note?: string | null;
}) {
  const item = await prisma.installmentScheduleItem.findFirst({
    where: { id: input.scheduleItemId, planId: input.planId },
  });
  if (!item) throw new Error('قسط یافت نشد.');
  if (item.paidAmount > 0 || item.status === 'paid') {
    throw new Error('فقط اقساط پرداخت‌نشده قابل حذف هستند.');
  }

  await prisma.installmentScheduleItem.delete({ where: { id: item.id } });

  const remaining = await prisma.installmentScheduleItem.findMany({
    where: { planId: input.planId },
    orderBy: { index: 'asc' },
  });
  await prisma.$transaction(
    remaining.map((row, idx) =>
      prisma.installmentScheduleItem.update({
        where: { id: row.id },
        data: { index: idx + 1 },
      }),
    ),
  );

  await logAdminAdjustment({
    planId: input.planId,
    note: input.note || `حذف قسط ${item.index}`,
    amount: -item.amount,
  });
  await refreshPlanTotals(input.planId);

  return prisma.installmentPlan.findUnique({
    where: { id: input.planId },
    include: {
      scheduleItems: { orderBy: { index: 'asc' } },
      payments: { orderBy: { createdAt: 'desc' } },
    },
  });
}

/** @deprecated use specific admin functions */
export async function adminAdjustInstallmentPlan(input: {
  planId: string;
  totalAmount?: number;
  note?: string | null;
}) {
  if (input.totalAmount == null) throw new Error('مبلغ کل الزامی است.');
  return updateInstallmentPlanTotal({
    planId: input.planId,
    totalAmount: input.totalAmount,
    note: input.note,
  });
}

export {
  softDeleteInstallmentPlan,
  softDeleteMembershipApplication,
  softDeleteFacilityRequest,
} from '@/lib/commerce/soft-delete';
