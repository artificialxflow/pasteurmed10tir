-- Phase 05 — Seed growth + note for PWA brand icons in Storage

insert into public.complaints (name, phone, subject, body, status) values
  ('بیمار تست', '09121111111', 'نمونه شکایت', 'این یک شکایت فیک برای تست ادمین است.', 'new');

insert into public.partner_requests (name, phone, email, organization, message, status) values
  ('شریک نمونه', '09125556666', 'partner@example.com', 'کلینیک همکار', 'درخواست همکاری تست', 'new');

do $$
declare
  pid uuid;
  did uuid;
begin
  select id into pid from public.profiles where email = 'patient1@pasteur.plus';
  if pid is not null then
    insert into public.club_profiles (profile_id, points, tier, visits)
    values (pid, 50, 'bronze', 1)
    on conflict (profile_id) do update set points = 50;

    insert into public.club_ledger (profile_id, points_delta, reason)
    values (pid, 50, 'seed رزرو نمونه');
  end if;

  select id into did from public.doctors order by sort_order limit 1;
  if did is not null and pid is not null then
    insert into public.doctor_reviews (doctor_id, profile_id, rating, comment, status)
    values (did, pid, 5, 'عالی — نظر فیک', 'pending');
  end if;
end $$;

insert into public.app_settings (key, value) values
  ('phase', '"05-growth-ops"'::jsonb),
  ('pwa.icons_bucket', '"brand"'::jsonb),
  ('pwa.icons_note', '"Upload icon-192.png and icon-512.png to Storage bucket brand; serve via Supabase URL (no CDN)."'::jsonb)
on conflict (key) do update set value = excluded.value, updated_at = now();
