-- Phase 05 — Growth: club, complaints, reviews, partners + brand note

create table if not exists public.club_profiles (
  profile_id uuid primary key references public.profiles (id) on delete cascade,
  points int not null default 0,
  tier text not null default 'bronze',
  visits int not null default 0,
  updated_at timestamptz not null default now()
);

create table if not exists public.club_ledger (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references public.profiles (id) on delete cascade,
  points_delta int not null,
  reason text,
  created_at timestamptz not null default now()
);

create table if not exists public.complaints (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid references public.profiles (id) on delete set null,
  name text,
  phone text,
  subject text not null,
  body text,
  status text not null default 'new',
  created_at timestamptz not null default now()
);

create table if not exists public.doctor_reviews (
  id uuid primary key default gen_random_uuid(),
  doctor_id uuid references public.doctors (id) on delete set null,
  profile_id uuid references public.profiles (id) on delete set null,
  rating int check (rating between 1 and 5),
  comment text,
  status text not null default 'pending',
  created_at timestamptz not null default now()
);

create table if not exists public.partner_requests (
  id uuid primary key default gen_random_uuid(),
  name text,
  phone text,
  email text,
  organization text,
  message text,
  status text not null default 'new',
  created_at timestamptz not null default now()
);
