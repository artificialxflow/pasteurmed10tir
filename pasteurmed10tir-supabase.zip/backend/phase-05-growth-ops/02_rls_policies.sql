-- Phase 05 — RLS

alter table public.club_profiles enable row level security;
alter table public.club_ledger enable row level security;
alter table public.complaints enable row level security;
alter table public.doctor_reviews enable row level security;
alter table public.partner_requests enable row level security;

do $$ begin
  create policy club_select on public.club_profiles for select to authenticated
  using (profile_id = auth.uid() or public.has_permission('club') or public.is_superadmin());
exception when duplicate_object then null; end $$;
do $$ begin
  create policy club_write on public.club_profiles for all to authenticated
  using (profile_id = auth.uid() or public.has_permission('club') or public.is_superadmin())
  with check (profile_id = auth.uid() or public.has_permission('club') or public.is_superadmin());
exception when duplicate_object then null; end $$;

do $$ begin
  create policy club_ledger_select on public.club_ledger for select to authenticated
  using (profile_id = auth.uid() or public.has_permission('club') or public.is_superadmin());
exception when duplicate_object then null; end $$;
do $$ begin
  create policy club_ledger_insert on public.club_ledger for insert to authenticated
  with check (public.is_staff() or profile_id = auth.uid());
exception when duplicate_object then null; end $$;

do $$ begin
  create policy complaints_select on public.complaints for select to authenticated
  using (profile_id = auth.uid() or public.has_permission('complaints') or public.is_superadmin());
exception when duplicate_object then null; end $$;
do $$ begin
  create policy complaints_insert on public.complaints for insert to authenticated
  with check (true);
exception when duplicate_object then null; end $$;
do $$ begin
  create policy complaints_update on public.complaints for update to authenticated
  using (public.is_superadmin() or public.has_permission('complaints'))
  with check (public.is_superadmin() or public.has_permission('complaints'));
exception when duplicate_object then null; end $$;

do $$ begin
  create policy reviews_select on public.doctor_reviews for select to authenticated
  using (status = 'approved' or profile_id = auth.uid() or public.has_permission('reviews') or public.is_superadmin());
exception when duplicate_object then null; end $$;
do $$ begin
  create policy reviews_insert on public.doctor_reviews for insert to authenticated
  with check (profile_id = auth.uid() or public.is_staff());
exception when duplicate_object then null; end $$;
do $$ begin
  create policy reviews_mod on public.doctor_reviews for update to authenticated
  using (public.is_superadmin() or public.has_permission('reviews'))
  with check (public.is_superadmin() or public.has_permission('reviews'));
exception when duplicate_object then null; end $$;

do $$ begin
  create policy partners_select on public.partner_requests for select to authenticated
  using (public.has_permission('partners') or public.is_superadmin());
exception when duplicate_object then null; end $$;
do $$ begin
  create policy partners_insert on public.partner_requests for insert to authenticated
  with check (true);
exception when duplicate_object then null; end $$;
do $$ begin
  create policy partners_update on public.partner_requests for update to authenticated
  using (public.is_superadmin() or public.has_permission('partners'))
  with check (public.is_superadmin() or public.has_permission('partners'));
exception when duplicate_object then null; end $$;
