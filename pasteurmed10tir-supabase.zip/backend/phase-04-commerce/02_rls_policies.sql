-- Phase 04 — RLS (staff permissions aligned with adminAccess)

alter table public.membership_plans enable row level security;
alter table public.memberships enable row level security;
alter table public.wallets enable row level security;
alter table public.installment_plans enable row level security;
alter table public.products enable row level security;
alter table public.shop_orders enable row level security;
alter table public.facility_requests enable row level security;
alter table public.visitors enable row level security;
alter table public.commissions enable row level security;

-- Helper macro-style policies
do $$ begin
  create policy membership_plans_select on public.membership_plans for select to authenticated using (active or public.is_staff());
exception when duplicate_object then null; end $$;
do $$ begin
  create policy membership_plans_write on public.membership_plans for all to authenticated
  using (public.is_superadmin() or public.has_permission('memberships'))
  with check (public.is_superadmin() or public.has_permission('memberships'));
exception when duplicate_object then null; end $$;

do $$ begin
  create policy memberships_select on public.memberships for select to authenticated
  using (profile_id = auth.uid() or public.has_permission('memberships') or public.is_superadmin());
exception when duplicate_object then null; end $$;
do $$ begin
  create policy memberships_insert on public.memberships for insert to authenticated
  with check (profile_id = auth.uid() or public.is_staff());
exception when duplicate_object then null; end $$;

do $$ begin
  create policy wallets_select on public.wallets for select to authenticated
  using (profile_id = auth.uid() or public.has_permission('wallets') or public.is_superadmin());
exception when duplicate_object then null; end $$;
do $$ begin
  create policy wallets_write on public.wallets for all to authenticated
  using (profile_id = auth.uid() or public.has_permission('wallets') or public.is_superadmin())
  with check (profile_id = auth.uid() or public.has_permission('wallets') or public.is_superadmin());
exception when duplicate_object then null; end $$;

do $$ begin
  create policy installments_select on public.installment_plans for select to authenticated
  using (profile_id = auth.uid() or public.has_permission('installments') or public.is_superadmin());
exception when duplicate_object then null; end $$;
do $$ begin
  create policy installments_write on public.installment_plans for all to authenticated
  using (public.is_superadmin() or public.has_permission('installments') or public.has_permission('facilities'))
  with check (public.is_superadmin() or public.has_permission('installments') or public.has_permission('facilities'));
exception when duplicate_object then null; end $$;

do $$ begin
  create policy products_select on public.products for select to authenticated using (active or public.is_staff());
exception when duplicate_object then null; end $$;
do $$ begin
  create policy products_write on public.products for all to authenticated
  using (public.is_superadmin() or public.has_permission('shop'))
  with check (public.is_superadmin() or public.has_permission('shop'));
exception when duplicate_object then null; end $$;

do $$ begin
  create policy orders_select on public.shop_orders for select to authenticated
  using (profile_id = auth.uid() or public.has_permission('shop') or public.is_superadmin());
exception when duplicate_object then null; end $$;
do $$ begin
  create policy orders_insert on public.shop_orders for insert to authenticated
  with check (profile_id = auth.uid() or public.is_staff());
exception when duplicate_object then null; end $$;

do $$ begin
  create policy facilities_select on public.facility_requests for select to authenticated
  using (profile_id = auth.uid() or public.has_permission('facilities') or public.is_superadmin());
exception when duplicate_object then null; end $$;
do $$ begin
  create policy facilities_insert on public.facility_requests for insert to authenticated
  with check (profile_id = auth.uid() or public.is_staff());
exception when duplicate_object then null; end $$;
do $$ begin
  create policy facilities_update on public.facility_requests for update to authenticated
  using (public.is_superadmin() or public.has_permission('facilities'))
  with check (public.is_superadmin() or public.has_permission('facilities'));
exception when duplicate_object then null; end $$;

do $$ begin
  create policy visitors_select on public.visitors for select to authenticated
  using (public.is_staff());
exception when duplicate_object then null; end $$;
do $$ begin
  create policy visitors_write on public.visitors for all to authenticated
  using (public.is_superadmin() or public.has_permission('visitors') or public.has_permission('commissions'))
  with check (public.is_superadmin() or public.has_permission('visitors') or public.has_permission('commissions'));
exception when duplicate_object then null; end $$;

do $$ begin
  create policy commissions_select on public.commissions for select to authenticated
  using (public.has_permission('commissions') or public.is_superadmin());
exception when duplicate_object then null; end $$;
do $$ begin
  create policy commissions_write on public.commissions for all to authenticated
  using (public.is_superadmin() or public.has_permission('commissions'))
  with check (public.is_superadmin() or public.has_permission('commissions'));
exception when duplicate_object then null; end $$;
