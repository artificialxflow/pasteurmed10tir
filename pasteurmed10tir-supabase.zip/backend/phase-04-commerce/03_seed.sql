-- Phase 04 — Seed commerce

insert into public.membership_plans (id, title, price_toman, credit_ceiling, features, active) values
  ('regular', 'عضویت عادی', 1000000, 15000000, '["سقف اعتبار ۱۵ میلیون"]'::jsonb, true),
  ('vip', 'عضویت VIP', 1600000, 30000000, '["سقف اعتبار ۳۰ میلیون","اولویت نوبت"]'::jsonb, true),
  ('shop-vip', 'VIP تجهیزات', 500000, 0, '["تخفیف فروشگاه"]'::jsonb, true)
on conflict (id) do update set
  price_toman = excluded.price_toman,
  credit_ceiling = excluded.credit_ceiling,
  title = excluded.title;

insert into public.visitors (name, code, phone, commission_rate, status) values
  ('ویزیتور نمونه', 'PASTEUR', '09123334444', 5, 'active')
on conflict (code) do update set commission_rate = 5, status = 'active';

insert into public.products (title, price_toman, stock, active) values
  ('مسواک برقی نمونه', 2500000, 10, true),
  ('نخ دندان بسته', 120000, 50, true);

-- Sample VIP membership + wallet + credit installments for patient1
do $$
declare
  pid uuid;
begin
  select id into pid from public.profiles where email = 'patient1@pasteur.plus';
  if pid is null then return; end if;

  insert into public.memberships (profile_id, plan_id, patient_name, patient_phone, amount, status)
  values (pid, 'vip', 'بیمار تست', '09121111111', 1600000, 'paid');

  insert into public.wallets (profile_id, ceiling, balance, kinds)
  values (pid, 30000000, 0, '["vip"]'::jsonb)
  on conflict (profile_id) do update set ceiling = 30000000, kinds = '["vip"]'::jsonb;

  insert into public.installment_plans (
    profile_id, phone, patient_name, source, title, total_amount, paid_amount, installment_count, due_dates, status
  ) values (
    pid, '09121111111', 'بیمار تست', 'credit',
    'اقساط بسته اعتباری ۳۰٬۰۰۰٬۰۰۰ تومان',
    30000000, 0, 6,
    array[
      (current_date + 30),
      (current_date + 60),
      (current_date + 90),
      (current_date + 120),
      (current_date + 150),
      (current_date + 180)
    ]::date[],
    'active'
  );

  insert into public.facility_requests (profile_id, name, phone, amount, description, status)
  values (pid, 'بیمار تست', '09121111111', 200000000, 'درخواست وام تجهیزات نمونه', 'pending');
end $$;

insert into public.app_settings (key, value) values ('phase', '"04-commerce"'::jsonb)
on conflict (key) do update set value = excluded.value, updated_at = now();
