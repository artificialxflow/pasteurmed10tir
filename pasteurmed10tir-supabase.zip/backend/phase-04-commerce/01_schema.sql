-- Phase 04 — Commerce: membership, wallet, installments, shop, facilities, visitors

do $$ begin
  create type public.installment_source as enum ('credit', 'facility', 'membership_legacy');
exception when duplicate_object then null; end $$;

create table if not exists public.membership_plans (
  id text primary key,
  title text not null,
  price_toman numeric not null,
  credit_ceiling numeric not null default 0,
  features jsonb not null default '[]'::jsonb,
  active boolean not null default true
);

create table if not exists public.memberships (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid references public.profiles (id) on delete set null,
  plan_id text references public.membership_plans (id),
  patient_name text,
  patient_phone text,
  amount numeric,
  status text not null default 'paid',
  created_at timestamptz not null default now()
);

create table if not exists public.wallets (
  profile_id uuid primary key references public.profiles (id) on delete cascade,
  ceiling numeric not null default 0,
  balance numeric not null default 0,
  kinds jsonb not null default '[]'::jsonb,
  updated_at timestamptz not null default now()
);

create table if not exists public.installment_plans (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid references public.profiles (id) on delete set null,
  phone text,
  patient_name text,
  source public.installment_source not null,
  title text not null,
  total_amount numeric not null,
  paid_amount numeric not null default 0,
  installment_count int not null default 6,
  due_dates date[] not null default '{}',
  status text not null default 'active',
  linked_request_id uuid,
  created_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  price_toman numeric not null,
  image_path text,
  stock int not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.shop_orders (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid references public.profiles (id) on delete set null,
  customer_name text,
  customer_phone text,
  total numeric not null,
  status text not null default 'new',
  items jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.facility_requests (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid references public.profiles (id) on delete set null,
  name text,
  phone text,
  amount numeric,
  description text,
  status text not null default 'pending',
  created_at timestamptz not null default now(),
  reviewed_at timestamptz
);

create table if not exists public.visitors (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  code text not null unique,
  phone text,
  commission_rate numeric not null default 5,
  status text not null default 'active',
  created_at timestamptz not null default now()
);

create table if not exists public.commissions (
  id uuid primary key default gen_random_uuid(),
  visitor_id uuid references public.visitors (id) on delete set null,
  referral_code text,
  source_type text,
  source_label text,
  customer_name text,
  customer_phone text,
  base_amount numeric not null,
  commission_rate numeric not null,
  commission_amount numeric not null,
  status text not null default 'pending',
  created_at timestamptz not null default now()
);
