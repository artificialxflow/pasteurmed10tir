-- =============================================================================
-- Phase 01 — Storage buckets (no external CDN; all media via Supabase Storage)
-- =============================================================================

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values
  ('avatars', 'avatars', false, 5242880, array['image/png', 'image/jpeg', 'image/webp']::text[]),
  ('gallery', 'gallery', false, 10485760, array['image/png', 'image/jpeg', 'image/webp']::text[]),
  ('products', 'products', false, 10485760, array['image/png', 'image/jpeg', 'image/webp']::text[]),
  ('brand', 'brand', false, 5242880, array['image/png', 'image/jpeg', 'image/webp', 'image/svg+xml']::text[])
on conflict (id) do update set
  public = excluded.public,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

-- Authenticated users: read own avatar folder; staff can manage brand/gallery later phases
drop policy if exists storage_avatars_own on storage.objects;
create policy storage_avatars_own
on storage.objects for all
to authenticated
using (
  bucket_id = 'avatars'
  and (storage.foldername(name))[1] = auth.uid()::text
)
with check (
  bucket_id = 'avatars'
  and (storage.foldername(name))[1] = auth.uid()::text
);

drop policy if exists storage_brand_staff on storage.objects;
create policy storage_brand_staff
on storage.objects for select
to authenticated
using (bucket_id = 'brand' and public.is_staff());

drop policy if exists storage_brand_write_superadmin on storage.objects;
create policy storage_brand_write_superadmin
on storage.objects for all
to authenticated
using (bucket_id = 'brand' and public.is_superadmin())
with check (bucket_id = 'brand' and public.is_superadmin());

drop policy if exists storage_gallery_select_staff on storage.objects;
create policy storage_gallery_select_staff
on storage.objects for select
to authenticated
using (bucket_id = 'gallery' and public.is_staff());

drop policy if exists storage_gallery_write_content on storage.objects;
create policy storage_gallery_write_content
on storage.objects for all
to authenticated
using (
  bucket_id = 'gallery'
  and (public.is_superadmin() or public.has_permission('gallery'))
)
with check (
  bucket_id = 'gallery'
  and (public.is_superadmin() or public.has_permission('gallery'))
);

drop policy if exists storage_products_select_staff on storage.objects;
create policy storage_products_select_staff
on storage.objects for select
to authenticated
using (bucket_id = 'products' and public.is_staff());

drop policy if exists storage_products_write_shop on storage.objects;
create policy storage_products_write_shop
on storage.objects for all
to authenticated
using (
  bucket_id = 'products'
  and (public.is_superadmin() or public.has_permission('shop'))
)
with check (
  bucket_id = 'products'
  and (public.is_superadmin() or public.has_permission('shop'))
);
