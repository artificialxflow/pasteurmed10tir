-- =============================================================================
-- Phase 01 — Seed: permissions, roles, settings
-- Auth users: run 04_seed_auth_users.sql AFTER this (or create via Dashboard)
-- =============================================================================

-- Permissions (codes match lib/adminAccess.ts)
insert into public.permissions (code, label_fa) values
  ('dashboard', 'داشبورد'),
  ('bookings', 'رزروها'),
  ('consultations', 'مشاوره‌ها'),
  ('reminders', 'یادآورها'),
  ('services', 'سرویس‌ها'),
  ('laserServices', 'لیزر'),
  ('nursingServices', 'پرستاری'),
  ('doctors', 'پزشکان'),
  ('consultationPrices', 'قیمت مشاوره'),
  ('gallery', 'گالری'),
  ('memberships', 'عضویت‌ها'),
  ('wallets', 'کیف اعتبار'),
  ('shop', 'فروشگاه'),
  ('commissions', 'پورسانت‌ها'),
  ('facilities', 'تسهیلات'),
  ('club', 'باشگاه'),
  ('visitors', 'ویزیتورها'),
  ('partners', 'همکاری‌ها'),
  ('insurances', 'بیمه‌ها و استعلام'),
  ('reviews', 'نظرات پزشکان'),
  ('complaints', 'شکایات'),
  ('help', 'آموزش سامانه'),
  ('installments', 'اقساط'),
  ('patients', 'تأیید کاربری / فرانشیز'),
  ('access', 'سطح دسترسی')
on conflict (code) do update set label_fa = excluded.label_fa;

-- Roles
insert into public.roles (code, name_fa, description) values
  ('superadmin', 'مدیر کل', 'دسترسی کامل به همه بخش‌ها'),
  ('ops', 'منشی / عملیات', 'رزرو، مشاوره و یادآور'),
  ('content', 'محتوا', 'سرویس‌ها، لیزر، پرستاری، پزشکان، گالری و قیمت'),
  ('finance', 'مالی', 'عضویت، کیف، فروشگاه، پورسانت، تسهیلات و …')
on conflict (code) do update set
  name_fa = excluded.name_fa,
  description = excluded.description;

-- superadmin → all permissions
insert into public.role_permissions (role_id, permission_id)
select r.id, p.id
from public.roles r
cross join public.permissions p
where r.code = 'superadmin'
on conflict do nothing;

-- ops
insert into public.role_permissions (role_id, permission_id)
select r.id, p.id
from public.roles r
join public.permissions p on p.code in ('dashboard', 'bookings', 'consultations', 'reminders')
where r.code = 'ops'
on conflict do nothing;

-- content
insert into public.role_permissions (role_id, permission_id)
select r.id, p.id
from public.roles r
join public.permissions p on p.code in (
  'dashboard', 'services', 'laserServices', 'nursingServices',
  'doctors', 'consultationPrices', 'gallery'
)
where r.code = 'content'
on conflict do nothing;

-- finance
insert into public.role_permissions (role_id, permission_id)
select r.id, p.id
from public.roles r
join public.permissions p on p.code in (
  'dashboard', 'memberships', 'wallets', 'shop', 'commissions',
  'facilities', 'installments', 'insurances', 'patients', 'complaints'
)
where r.code = 'finance'
on conflict do nothing;

insert into public.app_settings (key, value) values
  ('auth.email_confirm_required', 'false'::jsonb),
  ('site.url', '"https://pasteur.plus"'::jsonb),
  ('storage.no_external_cdn', 'true'::jsonb),
  ('phase', '"01-auth-rbac"'::jsonb)
on conflict (key) do update set value = excluded.value, updated_at = now();
