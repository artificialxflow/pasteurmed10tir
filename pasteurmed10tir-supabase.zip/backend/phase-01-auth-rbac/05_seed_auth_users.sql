-- =============================================================================
-- Phase 01 — Seed Auth users + staff_profiles + sample patient
-- Requires: pgcrypto, schema+roles already seeded (01–04)
-- Passwords (dev only): pasteur1403 / ops1403 / content1403 / finance1403 / patient1403
-- =============================================================================

create extension if not exists "pgcrypto";

-- Helper: create email user if missing (Supabase Auth compatible)
create or replace function public.seed_auth_user(
  p_id uuid,
  p_email text,
  p_password text,
  p_full_name text,
  p_phone text,
  p_user_type public.user_type
)
returns uuid
language plpgsql
security definer
set search_path = public, auth
as $$
declare
  v_id uuid := p_id;
begin
  if exists (select 1 from auth.users where email = p_email) then
    select id into v_id from auth.users where email = p_email;
    update public.profiles
    set full_name = p_full_name,
        phone = p_phone,
        user_type = p_user_type,
        email = p_email,
        status = case when p_user_type = 'staff' then 'approved'::public.profile_status else status end
    where id = v_id;
    return v_id;
  end if;

  insert into auth.users (
    instance_id,
    id,
    aud,
    role,
    email,
    encrypted_password,
    email_confirmed_at,
    raw_app_meta_data,
    raw_user_meta_data,
    created_at,
    updated_at,
    confirmation_token,
    recovery_token,
    email_change_token_new,
    email_change
  ) values (
    '00000000-0000-0000-0000-000000000000',
    v_id,
    'authenticated',
    'authenticated',
    p_email,
    crypt(p_password, gen_salt('bf')),
    now(),
    '{"provider":"email","providers":["email"]}'::jsonb,
    jsonb_build_object(
      'full_name', p_full_name,
      'phone', p_phone,
      'user_type', p_user_type::text
    ),
    now(),
    now(),
    '',
    '',
    '',
    ''
  );

  insert into auth.identities (
    id,
    user_id,
    identity_data,
    provider,
    provider_id,
    last_sign_in_at,
    created_at,
    updated_at
  ) values (
    v_id,
    v_id,
    jsonb_build_object('sub', v_id::text, 'email', p_email),
    'email',
    p_email,
    now(),
    now(),
    now()
  )
  on conflict do nothing;

  return v_id;
end;
$$;

do $$
declare
  id_admin uuid := 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaa1';
  id_ops uuid := 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaa2';
  id_content uuid := 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaa3';
  id_finance uuid := 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaa4';
  id_patient uuid := 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbb1';
  r_super uuid;
  r_ops uuid;
  r_content uuid;
  r_finance uuid;
begin
  perform public.seed_auth_user(id_admin, 'admin@pasteur.plus', 'pasteur1403', 'مدیر کل', '09120000001', 'staff');
  perform public.seed_auth_user(id_ops, 'ops@pasteur.plus', 'ops1403', 'منشی', '09120000002', 'staff');
  perform public.seed_auth_user(id_content, 'content@pasteur.plus', 'content1403', 'مدیر محتوا', '09120000003', 'staff');
  perform public.seed_auth_user(id_finance, 'finance@pasteur.plus', 'finance1403', 'مالی', '09120000004', 'staff');
  perform public.seed_auth_user(id_patient, 'patient1@pasteur.plus', 'patient1403', 'بیمار تست', '09121111111', 'patient');

  select id into r_super from public.roles where code = 'superadmin';
  select id into r_ops from public.roles where code = 'ops';
  select id into r_content from public.roles where code = 'content';
  select id into r_finance from public.roles where code = 'finance';

  insert into public.staff_profiles (profile_id, role_id, username, display_name, active)
  values
    (id_admin, r_super, 'admin', 'مدیر کل', true),
    (id_ops, r_ops, 'ops', 'منشی', true),
    (id_content, r_content, 'content', 'مدیر محتوا', true),
    (id_finance, r_finance, 'finance', 'مالی', true)
  on conflict (profile_id) do update set
    role_id = excluded.role_id,
    username = excluded.username,
    display_name = excluded.display_name,
    active = true;
end $$;
