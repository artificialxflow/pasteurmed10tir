-- =============================================================================
-- Phase 01 — RLS policies
-- =============================================================================

alter table public.profiles enable row level security;
alter table public.roles enable row level security;
alter table public.permissions enable row level security;
alter table public.role_permissions enable row level security;
alter table public.staff_profiles enable row level security;
alter table public.app_settings enable row level security;

-- profiles
drop policy if exists profiles_select_own_or_staff on public.profiles;
create policy profiles_select_own_or_staff
on public.profiles for select
to authenticated
using (
  id = auth.uid()
  or public.is_staff()
);

drop policy if exists profiles_update_own on public.profiles;
create policy profiles_update_own
on public.profiles for update
to authenticated
using (id = auth.uid() or public.is_superadmin())
with check (id = auth.uid() or public.is_superadmin());

drop policy if exists profiles_insert_own on public.profiles;
create policy profiles_insert_own
on public.profiles for insert
to authenticated
with check (id = auth.uid() or public.is_superadmin());

-- roles / permissions: readable by staff; writable by superadmin or access permission
drop policy if exists roles_select_staff on public.roles;
create policy roles_select_staff
on public.roles for select
to authenticated
using (public.is_staff());

drop policy if exists roles_write_access on public.roles;
create policy roles_write_access
on public.roles for all
to authenticated
using (public.is_superadmin() or public.has_permission('access'))
with check (public.is_superadmin() or public.has_permission('access'));

drop policy if exists permissions_select_staff on public.permissions;
create policy permissions_select_staff
on public.permissions for select
to authenticated
using (public.is_staff());

drop policy if exists permissions_write_access on public.permissions;
create policy permissions_write_access
on public.permissions for all
to authenticated
using (public.is_superadmin() or public.has_permission('access'))
with check (public.is_superadmin() or public.has_permission('access'));

drop policy if exists role_permissions_select_staff on public.role_permissions;
create policy role_permissions_select_staff
on public.role_permissions for select
to authenticated
using (public.is_staff());

drop policy if exists role_permissions_write_access on public.role_permissions;
create policy role_permissions_write_access
on public.role_permissions for all
to authenticated
using (public.is_superadmin() or public.has_permission('access'))
with check (public.is_superadmin() or public.has_permission('access'));

-- staff_profiles
drop policy if exists staff_select_staff on public.staff_profiles;
create policy staff_select_staff
on public.staff_profiles for select
to authenticated
using (public.is_staff() or profile_id = auth.uid());

drop policy if exists staff_write_access on public.staff_profiles;
create policy staff_write_access
on public.staff_profiles for all
to authenticated
using (public.is_superadmin() or public.has_permission('access'))
with check (public.is_superadmin() or public.has_permission('access'));

-- app_settings: staff read; superadmin write
drop policy if exists settings_select_staff on public.app_settings;
create policy settings_select_staff
on public.app_settings for select
to authenticated
using (public.is_staff());

drop policy if exists settings_write_superadmin on public.app_settings;
create policy settings_write_superadmin
on public.app_settings for all
to authenticated
using (public.is_superadmin())
with check (public.is_superadmin());
