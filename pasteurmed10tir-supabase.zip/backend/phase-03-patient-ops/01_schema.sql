-- Phase 03 — Patient ops: insurance, bookings, consultations, reminders
-- Depends on phase-01 (+ optionally 02 for doctors/prices)

do $$ begin
  create type public.inquiry_status as enum ('pending', 'approved', 'rejected');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.booking_status as enum ('pending', 'confirmed', 'cancelled', 'completed');
exception when duplicate_object then null; end $$;

create table if not exists public.insurance_companies (
  id text primary key,
  name text not null,
  kind text not null check (kind in ('base', 'complementary')),
  active boolean not null default true
);

create table if not exists public.patient_profiles (
  profile_id uuid primary key references public.profiles (id) on delete cascade,
  national_id text,
  base_insurance_id text references public.insurance_companies (id),
  complementary_insurance_id text references public.insurance_companies (id),
  franchise_percent numeric(5,2) not null default 10
    check (franchise_percent >= 0 and franchise_percent <= 100),
  reviewed_at timestamptz,
  review_note text,
  updated_at timestamptz not null default now()
);

create table if not exists public.insurance_inquiries (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid references public.profiles (id) on delete set null,
  patient_name text,
  phone text,
  visit_fee numeric,
  franchise_percent numeric(5,2),
  payable_amount numeric,
  status public.inquiry_status not null default 'pending',
  created_at timestamptz not null default now(),
  reviewed_at timestamptz
);

create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid references public.profiles (id) on delete set null,
  patient_name text,
  patient_phone text,
  doctor_id uuid references public.doctors (id) on delete set null,
  type_label text,
  amount numeric,
  visit_fee numeric,
  franchise_percent numeric(5,2),
  status public.booking_status not null default 'pending',
  referral_code text,
  scheduled_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.consultations (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid references public.profiles (id) on delete set null,
  patient_name text,
  patient_phone text,
  consultation_type_id uuid references public.consultation_types (id),
  visit_fee numeric,
  franchise_percent numeric(5,2),
  payable_amount numeric,
  notes text,
  status text not null default 'new',
  created_at timestamptz not null default now()
);

create table if not exists public.reminders (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid references public.profiles (id) on delete set null,
  phone text,
  title text not null,
  type text,
  due_at timestamptz,
  status text not null default 'scheduled',
  created_at timestamptz not null default now()
);
