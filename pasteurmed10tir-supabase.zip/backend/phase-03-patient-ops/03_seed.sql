-- Phase 03 — Seed insurance + sample patient ops data

insert into public.insurance_companies (id, name, kind, active) values
  ('tamin', 'تأمین اجتماعی', 'base', true),
  ('salamat', 'بیمه سلامت', 'base', true),
  ('niroo', 'نیروهای مسلح', 'base', true),
  ('dana', 'بیمه دانا', 'complementary', true),
  ('asia', 'بیمه آسیا', 'complementary', true),
  ('alborz', 'بیمه البرز', 'complementary', true),
  ('pasargad', 'بیمه پاسارگاد', 'complementary', true)
on conflict (id) do update set name = excluded.name, active = true;

-- Attach patient_profiles for seeded patient1 if exists
insert into public.patient_profiles (profile_id, national_id, base_insurance_id, complementary_insurance_id, franchise_percent)
select p.id, '0012345678', 'tamin', 'dana', 10
from public.profiles p
where p.email = 'patient1@pasteur.plus'
on conflict (profile_id) do update set
  franchise_percent = 10,
  complementary_insurance_id = 'dana',
  base_insurance_id = 'tamin';

-- Sample pending inquiry (350k × 10% = 35k)
insert into public.insurance_inquiries (
  profile_id, patient_name, phone, visit_fee, franchise_percent, payable_amount, status
)
select p.id, p.full_name, p.phone, 350000, 10, 35000, 'pending'
from public.profiles p
where p.email = 'patient1@pasteur.plus'
  and not exists (
    select 1 from public.insurance_inquiries i where i.profile_id = p.id and i.status = 'pending'
  );

insert into public.app_settings (key, value) values ('phase', '"03-patient-ops"'::jsonb)
on conflict (key) do update set value = excluded.value, updated_at = now();
