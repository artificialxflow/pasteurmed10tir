-- Phase 03 — RLS

alter table public.insurance_companies enable row level security;
alter table public.patient_profiles enable row level security;
alter table public.insurance_inquiries enable row level security;
alter table public.bookings enable row level security;
alter table public.consultations enable row level security;
alter table public.reminders enable row level security;

do $$ begin
  create policy ins_co_select on public.insurance_companies for select to authenticated using (active or public.is_staff());
exception when duplicate_object then null; end $$;
do $$ begin
  create policy ins_co_write on public.insurance_companies for all to authenticated
  using (public.is_superadmin() or public.has_permission('insurances'))
  with check (public.is_superadmin() or public.has_permission('insurances'));
exception when duplicate_object then null; end $$;

do $$ begin
  create policy patient_prof_select on public.patient_profiles for select to authenticated
  using (profile_id = auth.uid() or public.is_staff());
exception when duplicate_object then null; end $$;
do $$ begin
  create policy patient_prof_upsert_own on public.patient_profiles for insert to authenticated
  with check (profile_id = auth.uid());
exception when duplicate_object then null; end $$;
do $$ begin
  create policy patient_prof_update on public.patient_profiles for update to authenticated
  using (
    profile_id = auth.uid()
    or public.is_superadmin()
    or public.has_permission('patients')
  )
  with check (
    profile_id = auth.uid()
    or public.is_superadmin()
    or public.has_permission('patients')
  );
exception when duplicate_object then null; end $$;

do $$ begin
  create policy inquiry_select on public.insurance_inquiries for select to authenticated
  using (profile_id = auth.uid() or public.has_permission('insurances') or public.is_superadmin());
exception when duplicate_object then null; end $$;
do $$ begin
  create policy inquiry_insert on public.insurance_inquiries for insert to authenticated
  with check (profile_id = auth.uid() or public.is_staff());
exception when duplicate_object then null; end $$;
do $$ begin
  create policy inquiry_update_staff on public.insurance_inquiries for update to authenticated
  using (public.is_superadmin() or public.has_permission('insurances'))
  with check (public.is_superadmin() or public.has_permission('insurances'));
exception when duplicate_object then null; end $$;

do $$ begin
  create policy bookings_select on public.bookings for select to authenticated
  using (profile_id = auth.uid() or public.has_permission('bookings') or public.is_superadmin());
exception when duplicate_object then null; end $$;
do $$ begin
  create policy bookings_insert on public.bookings for insert to authenticated
  with check (profile_id = auth.uid() or public.is_staff());
exception when duplicate_object then null; end $$;
do $$ begin
  create policy bookings_update on public.bookings for update to authenticated
  using (public.is_superadmin() or public.has_permission('bookings'))
  with check (public.is_superadmin() or public.has_permission('bookings'));
exception when duplicate_object then null; end $$;

do $$ begin
  create policy consultations_select on public.consultations for select to authenticated
  using (profile_id = auth.uid() or public.has_permission('consultations') or public.is_superadmin());
exception when duplicate_object then null; end $$;
do $$ begin
  create policy consultations_insert on public.consultations for insert to authenticated
  with check (profile_id = auth.uid() or public.is_staff());
exception when duplicate_object then null; end $$;
do $$ begin
  create policy consultations_update on public.consultations for update to authenticated
  using (public.is_superadmin() or public.has_permission('consultations'))
  with check (public.is_superadmin() or public.has_permission('consultations'));
exception when duplicate_object then null; end $$;

do $$ begin
  create policy reminders_select on public.reminders for select to authenticated
  using (profile_id = auth.uid() or public.has_permission('reminders') or public.is_superadmin());
exception when duplicate_object then null; end $$;
do $$ begin
  create policy reminders_write on public.reminders for all to authenticated
  using (
    profile_id = auth.uid()
    or public.is_superadmin()
    or public.has_permission('reminders')
  )
  with check (
    profile_id = auth.uid()
    or public.is_superadmin()
    or public.has_permission('reminders')
  );
exception when duplicate_object then null; end $$;
