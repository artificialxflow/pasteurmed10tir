-- =============================================================================
-- RESET DATA — پاکسازی داده‌های اپ (برای staging / پایان تست)
-- هشدار: روی production فقط با تأیید صریح اجرا شود.
-- auth.users را حذف نمی‌کند مگر بلوک اختیاری پایین را از حالت توضیح خارج کنید.
-- =============================================================================

begin;

-- Growth
truncate table public.club_ledger restart identity cascade;
truncate table public.club_profiles restart identity cascade;
truncate table public.complaints restart identity cascade;
truncate table public.doctor_reviews restart identity cascade;
truncate table public.partner_requests restart identity cascade;

-- Commerce
truncate table public.commissions restart identity cascade;
truncate table public.visitors restart identity cascade;
truncate table public.facility_requests restart identity cascade;
truncate table public.shop_orders restart identity cascade;
truncate table public.products restart identity cascade;
truncate table public.installment_plans restart identity cascade;
truncate table public.wallets restart identity cascade;
truncate table public.memberships restart identity cascade;
-- membership_plans: معمولاً نگه داشته می‌شود؛ برای پاک کامل:
-- truncate table public.membership_plans restart identity cascade;

-- Patient ops
truncate table public.reminders restart identity cascade;
truncate table public.consultations restart identity cascade;
truncate table public.bookings restart identity cascade;
truncate table public.insurance_inquiries restart identity cascade;
truncate table public.patient_profiles restart identity cascade;
-- insurance_companies: مرجع؛ معمولاً truncate نشود

-- Catalog (اختیاری — به‌صورت پیش‌فرض پاک می‌شود برای ریست کامل محتوا)
truncate table public.help_items restart identity cascade;
truncate table public.gallery_items restart identity cascade;
truncate table public.specialty_tariffs restart identity cascade;
truncate table public.consultation_types restart identity cascade;
truncate table public.nursing_services restart identity cascade;
truncate table public.nursing_categories restart identity cascade;
truncate table public.laser_services restart identity cascade;
truncate table public.services restart identity cascade;
truncate table public.doctors restart identity cascade;

-- Storage objects (مسیرهای media) — فقط objects؛ bucketها می‌مانند
delete from storage.objects
where bucket_id in ('avatars', 'gallery', 'products', 'brand');

update public.app_settings
set value = '"reset"'::jsonb, updated_at = now()
where key = 'phase';

commit;

-- ---------------------------------------------------------------------------
-- OPTIONAL: حذف کاربران Auth غیرسیستمی (خطرناک)
-- کاربران seed با ایمیل @pasteur.plus را نگه می‌دارد مگر خط زیر را باز کنید.
-- ---------------------------------------------------------------------------
-- delete from auth.users where email not like '%@pasteur.plus';
--
-- برای حذف کامل کاربران seed هم:
-- delete from auth.users where email like '%@pasteur.plus';
-- (staff_profiles و profiles با cascade پاک می‌شوند)
-- سپس دوباره phase-01 seedها را اجرا کنید.
