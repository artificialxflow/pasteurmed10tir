-- Phase 02 — Seed catalog (text only; upload images to Storage bucket gallery/brand later)

insert into public.doctors (full_name, specialty, days_label, hours_label, active, sort_order) values
  ('دکتر نمونه عمومی', 'پزشکی عمومی', 'شنبه تا چهارشنبه', '۹–۱۳', true, 1),
  ('دکتر نمونه دندان', 'دندانپزشکی عمومی', 'یکشنبه و سه‌شنبه', '۱۶–۲۰', true, 2)
on conflict do nothing;

insert into public.services (title, description, price_toman, active, sort_order) values
  ('ویزیت عمومی', 'ویزیت پایه درمانگاه', 350000, true, 1),
  ('جرم‌گیری', 'سرویس دندانپزشکی نمونه', 800000, true, 2);

insert into public.laser_services (title, description, price_toman, active) values
  ('لیزر موهای زائد (ناحیه نمونه)', 'تعرفه نمونه', 1200000, true);

insert into public.nursing_categories (title, description, sort_order) values
  ('مراقبت در منزل', 'خدمات پرستاری نمونه', 1);

insert into public.nursing_services (category_id, title, price_toman, active)
select id, 'تزریق در منزل', 450000, true from public.nursing_categories limit 1;

insert into public.consultation_types (code, title, price_toman, active) values
  ('video_gp', 'ویزیت تصویری پزشکی عمومی', 350000, true),
  ('text_gp', 'مشاوره متنی عمومی', 200000, true)
on conflict (code) do update set price_toman = excluded.price_toman, title = excluded.title;

insert into public.specialty_tariffs (specialty, visit_fee_toman, active) values
  ('پزشکی عمومی', 350000, true),
  ('دندانپزشکی', 400000, true);

insert into public.gallery_items (title, category, active, sort_order) values
  ('نمونه قبل/بعد ۱', 'دندانپزشکی', true, 1),
  ('نمونه قبل/بعد ۲', 'زیبایی', true, 2);

insert into public.help_items (title, body, sort_order, active) values
  ('راهنمای پنل کاربری', 'بیمه و فرانشیز را در پنل کاربری ثبت کنید.', 1, true),
  ('راهنمای رزرو نوبت', 'از بخش دندانپزشکی نوبت بگیرید.', 2, true);

update public.app_settings set value = '"02-catalog-content"'::jsonb, updated_at = now()
where key = 'phase';
insert into public.app_settings (key, value) values ('phase', '"02-catalog-content"'::jsonb)
on conflict (key) do update set value = excluded.value, updated_at = now();
