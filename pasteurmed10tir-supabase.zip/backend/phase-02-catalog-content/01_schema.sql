-- Phase 02 — Catalog & content schema
-- Depends on phase-01

create table if not exists public.doctors (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  specialty text,
  days_label text,
  hours_label text,
  photo_path text,
  active boolean not null default true,
  sort_order int not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.services (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  price_toman numeric,
  image_path text,
  active boolean not null default true,
  sort_order int not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.laser_services (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  price_toman numeric,
  image_path text,
  active boolean not null default true,
  sort_order int not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.nursing_categories (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  sort_order int not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.nursing_services (
  id uuid primary key default gen_random_uuid(),
  category_id uuid references public.nursing_categories (id) on delete set null,
  title text not null,
  description text,
  price_toman numeric,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.gallery_items (
  id uuid primary key default gen_random_uuid(),
  title text,
  category text,
  before_path text,
  after_path text,
  image_path text,
  active boolean not null default true,
  sort_order int not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.consultation_types (
  id uuid primary key default gen_random_uuid(),
  code text unique,
  title text not null,
  price_toman numeric not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.specialty_tariffs (
  id uuid primary key default gen_random_uuid(),
  specialty text not null,
  visit_fee_toman numeric not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.help_items (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  body text,
  file_path text,
  sort_order int not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now()
);
