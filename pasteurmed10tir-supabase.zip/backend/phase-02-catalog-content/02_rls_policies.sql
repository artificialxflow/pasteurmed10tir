-- Phase 02 — RLS

alter table public.doctors enable row level security;
alter table public.services enable row level security;
alter table public.laser_services enable row level security;
alter table public.nursing_categories enable row level security;
alter table public.nursing_services enable row level security;
alter table public.gallery_items enable row level security;
alter table public.consultation_types enable row level security;
alter table public.specialty_tariffs enable row level security;
alter table public.help_items enable row level security;

-- Public read of active catalog (authenticated patients + staff)
do $$ begin
  create policy doctors_select_active on public.doctors for select to authenticated
  using (active = true or public.is_staff());
exception when duplicate_object then null; end $$;

do $$ begin
  create policy doctors_write on public.doctors for all to authenticated
  using (public.is_superadmin() or public.has_permission('doctors'))
  with check (public.is_superadmin() or public.has_permission('doctors'));
exception when duplicate_object then null; end $$;

do $$ begin
  create policy services_select on public.services for select to authenticated
  using (active = true or public.is_staff());
exception when duplicate_object then null; end $$;
do $$ begin
  create policy services_write on public.services for all to authenticated
  using (public.is_superadmin() or public.has_permission('services'))
  with check (public.is_superadmin() or public.has_permission('services'));
exception when duplicate_object then null; end $$;

do $$ begin
  create policy laser_select on public.laser_services for select to authenticated
  using (active = true or public.is_staff());
exception when duplicate_object then null; end $$;
do $$ begin
  create policy laser_write on public.laser_services for all to authenticated
  using (public.is_superadmin() or public.has_permission('laserServices'))
  with check (public.is_superadmin() or public.has_permission('laserServices'));
exception when duplicate_object then null; end $$;

do $$ begin
  create policy nursing_cat_select on public.nursing_categories for select to authenticated using (true);
exception when duplicate_object then null; end $$;
do $$ begin
  create policy nursing_cat_write on public.nursing_categories for all to authenticated
  using (public.is_superadmin() or public.has_permission('nursingServices'))
  with check (public.is_superadmin() or public.has_permission('nursingServices'));
exception when duplicate_object then null; end $$;

do $$ begin
  create policy nursing_svc_select on public.nursing_services for select to authenticated
  using (active = true or public.is_staff());
exception when duplicate_object then null; end $$;
do $$ begin
  create policy nursing_svc_write on public.nursing_services for all to authenticated
  using (public.is_superadmin() or public.has_permission('nursingServices'))
  with check (public.is_superadmin() or public.has_permission('nursingServices'));
exception when duplicate_object then null; end $$;

do $$ begin
  create policy gallery_select on public.gallery_items for select to authenticated
  using (active = true or public.is_staff());
exception when duplicate_object then null; end $$;
do $$ begin
  create policy gallery_write on public.gallery_items for all to authenticated
  using (public.is_superadmin() or public.has_permission('gallery'))
  with check (public.is_superadmin() or public.has_permission('gallery'));
exception when duplicate_object then null; end $$;

do $$ begin
  create policy ctype_select on public.consultation_types for select to authenticated
  using (active = true or public.is_staff());
exception when duplicate_object then null; end $$;
do $$ begin
  create policy ctype_write on public.consultation_types for all to authenticated
  using (public.is_superadmin() or public.has_permission('consultationPrices'))
  with check (public.is_superadmin() or public.has_permission('consultationPrices'));
exception when duplicate_object then null; end $$;

do $$ begin
  create policy tariff_select on public.specialty_tariffs for select to authenticated
  using (active = true or public.is_staff());
exception when duplicate_object then null; end $$;
do $$ begin
  create policy tariff_write on public.specialty_tariffs for all to authenticated
  using (public.is_superadmin() or public.has_permission('consultationPrices'))
  with check (public.is_superadmin() or public.has_permission('consultationPrices'));
exception when duplicate_object then null; end $$;

do $$ begin
  create policy help_select on public.help_items for select to authenticated
  using (active = true or public.is_staff());
exception when duplicate_object then null; end $$;
do $$ begin
  create policy help_write on public.help_items for all to authenticated
  using (public.is_superadmin() or public.has_permission('help'))
  with check (public.is_superadmin() or public.has_permission('help'));
exception when duplicate_object then null; end $$;
