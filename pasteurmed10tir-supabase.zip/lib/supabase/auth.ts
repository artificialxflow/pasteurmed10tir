import {
  type AdminPermission,
  type AdminSession,
  ALL_ADMIN_PERMISSIONS,
  firstAllowedAdminPath,
} from "@/lib/adminAccess";
import { getSupabaseBrowser, isSupabaseConfigured } from "@/lib/supabase/client";
import { PasteurStorage } from "@/lib/storage";

const STAFF_EMAIL_DOMAIN = "pasteur.plus";

/** Map UI username (admin) or full email to Auth email. */
export function resolveStaffEmail(usernameOrEmail: string): string {
  const raw = usernameOrEmail.trim().toLowerCase();
  if (!raw) return raw;
  if (raw.includes("@")) return raw;
  return `${raw}@${STAFF_EMAIL_DOMAIN}`;
}

type StaffRow = {
  profile_id: string;
  username: string | null;
  display_name: string;
  active: boolean;
  roles: { id: string; code: string; name_fa: string } | null;
};

export async function fetchStaffAdminSession(): Promise<AdminSession | null> {
  const supabase = getSupabaseBrowser();
  if (!supabase) return null;

  const { data: authData, error: authError } = await supabase.auth.getUser();
  if (authError || !authData.user) return null;

  const { data: staff, error: staffError } = await supabase
    .from("staff_profiles")
    .select("profile_id, username, display_name, active, roles(id, code, name_fa)")
    .eq("profile_id", authData.user.id)
    .maybeSingle();

  if (staffError || !staff || staff.active === false) return null;

  const row = staff as unknown as StaffRow;
  const roleId = row.roles?.id;
  if (!roleId) return null;

  const { data: permRows, error: permError } = await supabase
    .from("role_permissions")
    .select("permissions(code)")
    .eq("role_id", roleId);

  if (permError) return null;

  const permissions = (permRows || [])
    .map((row) => {
      const p = row.permissions as unknown as { code: string } | { code: string }[] | null;
      if (!p) return null;
      if (Array.isArray(p)) return p[0]?.code || null;
      return p.code;
    })
    .filter((code): code is string => Boolean(code))
    .filter((code): code is AdminPermission =>
      (ALL_ADMIN_PERMISSIONS as string[]).includes(code),
    );

  // superadmin safety: if role code is superadmin, grant all
  const finalPermissions =
    row.roles?.code === "superadmin" ? [...ALL_ADMIN_PERMISSIONS] : permissions;

  if (finalPermissions.length === 0) return null;

  const session: AdminSession = {
    userId: row.profile_id,
    username: row.username || authData.user.email || "staff",
    displayName: row.display_name || row.username || "کارمند",
    roleId,
    roleName: row.roles?.name_fa || row.roles?.code || "staff",
    permissions: finalPermissions,
  };

  PasteurStorage.setAdminSession(session);
  return session;
}

export async function staffLogin(
  usernameOrEmail: string,
  password: string,
): Promise<{ session: AdminSession | null; error: string | null }> {
  if (!isSupabaseConfigured()) {
    const session = PasteurStorage.adminLogin(usernameOrEmail, password);
    return {
      session,
      error: session ? null : "نام کاربری یا رمز عبور اشتباه است، یا حساب غیرفعال است.",
    };
  }

  const supabase = getSupabaseBrowser();
  if (!supabase) {
    return { session: null, error: "پیکربندی Supabase ناقص است." };
  }

  const email = resolveStaffEmail(usernameOrEmail);
  const { error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) {
    return { session: null, error: error.message || "ورود ناموفق بود." };
  }

  const session = await fetchStaffAdminSession();
  if (!session) {
    await supabase.auth.signOut();
    PasteurStorage.adminLogout();
    return {
      session: null,
      error: "این حساب دسترسی پنل مدیریت ندارد.",
    };
  }

  return { session, error: null };
}

export async function staffLogout(): Promise<void> {
  const supabase = getSupabaseBrowser();
  if (supabase) await supabase.auth.signOut();
  PasteurStorage.adminLogout();
}

export async function ensureStaffSession(): Promise<AdminSession | null> {
  if (!isSupabaseConfigured()) {
    PasteurStorage.initAdminAccessIfNeeded();
    return PasteurStorage.getAdminSession();
  }
  return fetchStaffAdminSession();
}

export function staffHomePath(session: AdminSession): string {
  return firstAllowedAdminPath(session.permissions);
}

export async function patientAuthRegister(input: {
  email: string;
  password: string;
  fullName: string;
  phone: string;
}): Promise<{ error: string | null }> {
  const supabase = getSupabaseBrowser();
  if (!supabase) return { error: "پیکربندی Supabase ناقص است." };

  const { data, error } = await supabase.auth.signUp({
    email: input.email.trim().toLowerCase(),
    password: input.password,
    options: {
      data: {
        full_name: input.fullName.trim(),
        phone: input.phone.trim(),
        user_type: "patient",
      },
    },
  });

  if (error) return { error: error.message };

  // Ensure profile fields if trigger already created row
  if (data.user) {
    await supabase
      .from("profiles")
      .update({
        full_name: input.fullName.trim(),
        phone: input.phone.trim(),
        user_type: "patient",
      })
      .eq("id", data.user.id);
  }

  return { error: null };
}

export async function patientAuthLogin(input: {
  email: string;
  password: string;
}): Promise<{ error: string | null }> {
  const supabase = getSupabaseBrowser();
  if (!supabase) return { error: "پیکربندی Supabase ناقص است." };

  const { error } = await supabase.auth.signInWithPassword({
    email: input.email.trim().toLowerCase(),
    password: input.password,
  });

  if (error) return { error: error.message };
  return { error: null };
}

export async function patientAuthLogout(): Promise<void> {
  const supabase = getSupabaseBrowser();
  if (supabase) await supabase.auth.signOut();
  PasteurStorage.patientLogout();
}

export async function loadPatientProfileFromAuth(): Promise<{
  id: string;
  email: string | null;
  full_name: string | null;
  phone: string | null;
  status: string;
} | null> {
  const supabase = getSupabaseBrowser();
  if (!supabase) return null;
  const { data: authData } = await supabase.auth.getUser();
  if (!authData.user) return null;

  const { data } = await supabase
    .from("profiles")
    .select("id, email, full_name, phone, status")
    .eq("id", authData.user.id)
    .maybeSingle();

  return data;
}
