# TODO v4 — فاز ۴: عضویت، کیف، اقساط، فروشگاه، تسهیلات، پورسانت

## ترتیب SQL — `backend/phase-04-commerce/`
1. [ ] `01_schema.sql`
2. [ ] `02_rls_policies.sql`
3. [ ] `03_seed.sql`

## چک‌لیست منطقی (هم‌راستا با todo فرانت v4)
- [ ] اقساط `credit` / `facility` — نه قسط‌بندی خودکار حق عضویت
- [ ] تأیید facility → ساخت installment source=facility (در لایه API/trigger فاز اتصال)
- [ ] پورسانت: ذخیره `base_amount` + `source_type` شفاف
- [ ] تصویر محصول فقط `products` bucket

## تست سرور

### finance / admin
| لینک | کار | انتظار |
|------|-----|--------|
| `/admin/memberships` | مشاهده VIP بیمار تست | مبلغ ۱٫۶م + سقف ۳۰م در کیف |
| `/admin/wallets` | سقف patient1 | ۳۰٬۰۰۰٬۰۰۰ |
| `/admin/facilities` | تأیید وام ۲۰۰م | status=approved + اقساط facility |
| `/admin/installments` | فیلتر credit/facility | بدون membership به‌عنوان منبع اصلی |
| `/admin/commissions` | در صورت تراکنش با کد PASTEUR | مبنا = مبلغ تراکنش |
| `/admin/shop` | محصول seed | ۲ محصول |

### بیمار
| لینک | انتظار |
|------|--------|
| `/installments` یا `/app/installments` | کارت اعتبار (نه عضویت ۱٫۶م شش‌قسمتی اشتباه) |
| `/shop` | محصولات از DB + تصویر Storage |

### Supabase
| جدول | انتظار seed |
|------|-------------|
| membership_plans | regular, vip, shop-vip |
| visitors | کد PASTEUR |
| facility_requests | یک pending ۲۰۰م |

## معیار Done
- [ ] سناریو VIP→کیف→وام در ادمین دیده می‌شود
- [ ] UI ثابت
