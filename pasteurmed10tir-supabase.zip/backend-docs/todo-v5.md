# TODO v5 — فاز ۵: باشگاه، شکایات، نظرات، همکاری + harden + Reset

## ترتیب SQL — `backend/phase-05-growth-ops/`
1. [ ] `01_schema.sql`
2. [ ] `02_rls_policies.sql`
3. [ ] `03_seed.sql`

سپس در صورت نیاز پاکسازی کامل تست:
4. [ ] `backend/reset-data.sql` (با احتیاط روی سرور)

## چک‌لیست
- [ ] club_profiles / club_ledger
- [ ] complaints, doctor_reviews, partner_requests
- [ ] آپلود `icon-192.png` و `icon-512.png` به bucket **`brand`** (نه CDN)
- [ ] بازبینی RLS همه فازها
- [ ] مستند reset

## تست سرور

| نقش | لینک | کار | انتظار |
|-----|------|-----|--------|
| finance/admin | `/admin/complaints` | مشاهده شکایت seed | status=new؛ تغییر به بررسی‌شده |
| admin | `/admin/reviews` | تأیید نظر pending | status=approved |
| admin | `/admin/partners` | درخواست همکاری | ردیف seed |
| admin | `/admin/club` | امتیاز patient1 | ≥ ۵۰ |
| بیمار | `/club` یا `/app/club` | مشاهده امتیاز | از DB |
| بیمار | `/complaints` | ثبت شکایت جدید | در ادمین ظاهر شود |

### PWA / برند
| مسیر Supabase | کار | انتظار |
|---------------|-----|--------|
| Storage → `brand` | آپلود آیکون‌های PWA | فایل‌ها فقط روی Storage پروژه |
| اپ نصب‌شده | آیکون | از URL پروژه Supabase (نه دامنه CDN ثالث) |

## معیار Done کل بک‌اند
- [ ] پنج فاز SQL روی سرور اجرا شده
- [ ] نقش‌ها و منوهای ادمین مطابق permission
- [ ] UI فرانت بدون بازطراحی
- [ ] `reset-data.sql` یک‌بار روی staging تست شده
