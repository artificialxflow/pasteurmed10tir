# TODO v1 — فاز ۱: احراز هویت و تنظیمات اولیه (Supabase)

> فرانت Next/PWA ثابت است؛ فقط اتصال داده. بدون CDN خارجی برای رسانه.

## هدف
- Login / Register با Supabase Auth **بدون Email Verification**
- پروفایل، نقش‌ها، permissionها (مطابق `lib/adminAccess.ts`)
- bucketهای خالی Storage
- Seed کاربران staff + یک بیمار تست

## پیش‌نیاز Dashboard (دقیق)

### Authentication → Providers → Email
- [ ] Enable Email = **ON**
- [ ] **Confirm email = OFF**
- [ ] (اختیاری dev) Secure email change = OFF

### Authentication → URL Configuration
- [ ] Site URL = `https://pasteur.plus` (یا دامنه staging)
- [ ] Redirect URLs شامل:
  - `https://pasteur.plus/**`
  - `https://pasteur.plus/admin/**`
  - `https://pasteur.plus/account`
  - `https://pasteur.plus/app/account`

### Project Settings → API
- [ ] کپی `Project URL` و `anon` / `service_role` به env سرور

## متغیرهای محیطی

```env
NEXT_PUBLIC_SUPABASE_URL=https://XXXX.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJ...
SUPABASE_SERVICE_ROLE_KEY=eyJ...
NEXT_PUBLIC_SITE_URL=https://pasteur.plus
```

فایل نمونه: `.env.example` در ریشه پروژه.

## ترتیب اجرای SQL (SQL Editor)

پوشه: `backend/phase-01-auth-rbac/`

1. [ ] `01_schema.sql`
2. [ ] `02_rls_policies.sql`
3. [ ] `03_storage.sql`
4. [ ] `04_seed.sql`
5. [ ] `05_seed_auth_users.sql`

## فرانت فاز ۱ (انجام‌شده در ریپو)

- [x] پکیج `@supabase/supabase-js`
- [x] `lib/supabase/client.ts` + `lib/supabase/auth.ts`
- [x] `/admin/login` → Supabase Auth (نام کاربری `admin` ≡ `admin@pasteur.plus`)
- [x] `AdminShell` نقش/مجوز از `staff_profiles` + `role_permissions`
- [x] `/account` و `/app/account` → ورود/ثبت‌نام بیمار با ایمیل+رمز
- [x] اگر env ست نباشد، fallback به mock قبلی

### قبل از push/تست سرور
1. SQLهای بالا را در Supabase اجرا کنید
2. روی اپ Next این envها را بگذارید و **Rebuild**:
   - `NEXT_PUBLIC_SUPABASE_URL=https://supabase.pasteur.plus`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY=...`
   - `SUPABASE_SERVICE_ROLE_KEY=...` (فقط سرور)
   - `NEXT_PUBLIC_SITE_URL=https://pasteur.plus`
3. Auth GoTrue: `GOTRUE_MAILER_AUTOCONFIRM=true`
4. Push و deploy فرانت
5. تست فقط از UI (نیازی به چک دستی Studio نیست مگر خطا)

## چک‌لیست پیاده‌سازی

- [ ] جداول `profiles`, `roles`, `permissions`, `role_permissions`, `staff_profiles`, `app_settings`
- [ ] Trigger ساخت پروفایل روی `auth.users`
- [ ] توابع `is_staff`, `has_permission`, `is_superadmin`
- [ ] RLS فعال
- [ ] Buckets: `avatars`, `gallery`, `products`, `brand`
- [ ] Seed نقش‌ها: superadmin / ops / content / finance
- [ ] Seed کاربران (جدول زیر)

| ایمیل | رمز | نقش |
|--------|-----|-----|
| admin@pasteur.plus | pasteur1403 | superadmin |
| ops@pasteur.plus | ops1403 | ops |
| content@pasteur.plus | content1403 | content |
| finance@pasteur.plus | finance1403 | finance |
| patient1@pasteur.plus | patient1403 | patient |

---

## تست کامل روی سرور (نه لوکال)

جایگزین کنید: `https://pasteur.plus` با دامنه واقعی staging/production.

### A) پنل Supabase (سطح Owner پروژه)

| # | مسیر منو | کار | انتظار |
|---|----------|-----|--------|
| A1 | **Authentication → Users** | لیست کاربران seed | ۵ کاربر با ایمیل‌های بالا؛ Confirmed بدون لینک ایمیل |
| A2 | **Authentication → Providers → Email** | باز کردن تنظیمات | Confirm email = Disabled |
| A3 | **Table Editor → `profiles`** | مشاهده | ۵ ردیف؛ staff با status=approved؛ patient می‌تواند pending باشد |
| A4 | **Table Editor → `roles`** | مشاهده | ۴ نقش |
| A5 | **Table Editor → `role_permissions`** | فیلتر role=ops | فقط dashboard, bookings, consultations, reminders |
| A6 | **Storage → Buckets** | لیست | avatars, gallery, products, brand |
| A7 | **SQL → New query** | `select count(*) from public.permissions;` | ۲۵ |

### B) کاربر معمولی (بیمار) — بدون دسترسی ادمین

| # | لینک | کار با داده فیک | انتظار |
|---|------|-----------------|--------|
| B1 | Auth API یا UI حساب پس از hook: مسیر هدف `/account` و `/app/account` | Register: `test.patient+srv@pasteur.plus` / `Test1403!` / نام «بیمار سرور» / meta `user_type=patient` | موفقیت؛ **بدون** پیام تأیید ایمیل |
| B2 | همان | Logout سپس Login | session برقرار |
| B3 | `https://pasteur.plus/admin/login` | تلاش ورود بیمار | عدم دسترسی staff / رد پنل ادمین |
| B4 | Supabase → **Authentication → Users** | کاربر جدید | ردیف جدید + ردیف در `profiles` |

### C) کارکنان — پنل ادمین اپ

مسیر ورود: `https://pasteur.plus/admin/login`  
(پس از اتصال Auth به همان فرم موجود؛ ظاهر ثابت)

| کاربر | پس از ورود URL پایه | منوهایی که باید دیده شود | منویی که نباید / باید رد شود |
|--------|---------------------|---------------------------|-------------------------------|
| admin@… / pasteur1403 | `/admin` | همه از جمله **سطح دسترسی** `/admin/access` | — |
| ops@… / ops1403 | `/admin` | داشبورد، رزروها، مشاوره‌ها، یادآورها | `/admin/access`, `/admin/shop`, `/admin/gallery` |
| content@… | `/admin` | سرویس‌ها، لیزر، پرستاری، پزشکان، قیمت مشاوره، گالری | `/admin/facilities`, `/admin/access` |
| finance@… | `/admin` | عضویت، کیف، فروشگاه، پورسانت، تسهیلات، اقساط، بیمه، تأیید کاربری، شکایات | `/admin/access` (مگر بعداً داده شود) |

تست‌های اجباری:

| # | لینک | نقش | کار | انتظار |
|---|------|-----|-----|--------|
| C1 | `/admin/access` | ops | باز کردن مستقیم URL | 403 / redirect / بدون داده حساس |
| C2 | `/admin/access` | admin | مشاهده نقش‌ها از DB | لیست roles مطابق seed |
| C3 | SQL: `select public.has_permission('bookings');` به‌عنوان ops (از کلاینت با JWT) | ops | — | true |
| C4 | همان برای `access` | ops | — | false |

### D) خروجی منفی (باید شکست بخورد اگر پیکربندی غلط باشد)

- [ ] اگر Confirm email روشن بماند → Login تا قبل از تأیید شکست
- [ ] اگر `NEXT_PUBLIC_SUPABASE_URL` اشتباه → Network error روی `/auth/v1/*`
- [ ] `SUPABASE_SERVICE_ROLE_KEY` نباید در bundle کلاینت باشد

## معیار Done فاز ۱
- [ ] همه SQL بدون خطا اجرا شده
- [ ] تست‌های A–C روی سرور پاس
- [ ] UI فرانت از نظر ظاهر تغییر نکرده
- [ ] هیچ تصویر از CDN خارجی لود نمی‌شود
