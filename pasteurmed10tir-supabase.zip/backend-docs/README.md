# Backend Docs — Pasteur Plus (Supabase)

چک‌لیست فازهای بک‌اند و دستورالعمل تست روی سرور.

| فایل | فاز |
|------|-----|
| [todo-v1.md](./todo-v1.md) | Auth + RBAC + Storage buckets |
| [todo-v2.md](./todo-v2.md) | کاتالوگ و محتوا |
| [todo-v3.md](./todo-v3.md) | بیمار / رزرو / بیمه |
| [todo-v4.md](./todo-v4.md) | مالی و فروشگاه |
| [todo-v5.md](./todo-v5.md) | رشد + harden + لینک Reset |

اسکریپت‌ها: `../backend/`  
Reset نهایی: `../backend/reset-data.sql`

## قانون طلایی
فرانت و UI تغییر ظاهری ندارد. رسانه فقط از Supabase Storage (بدون CDN خارجی).
