# TODO v2 — فاز ۲: کاتالوگ و محتوا

> وابسته به فاز ۱. تصاویر فقط از Supabase Storage (`gallery`, مسیرهای `*_path`).

## ترتیب SQL — `backend/phase-02-catalog-content/`
1. [ ] `01_schema.sql`
2. [ ] `02_rls_policies.sql`
3. [ ] `03_seed.sql`

## چک‌لیست
- [ ] جداول doctors, services, laser_services, nursing_*, gallery_items, consultation_types, specialty_tariffs, help_items
- [ ] RLS: بیمار active را می‌خواند؛ content/superadmin می‌نویسد
- [ ] آپلود تست یک تصویر به bucket `gallery` (نه CDN)
- [ ] به‌روزرسانی `image_path` / `photo_path` با مسیر Storage

## تست سرور

### Supabase
| مسیر | کار | انتظار |
|------|-----|--------|
| Table Editor → `doctors` | مشاهده seed | ≥ ۲ پزشک |
| Table Editor → `consultation_types` | کد `video_gp` | قیمت ۳۵۰٬۰۰۰ |
| Storage → `gallery` | آپلود PNG تست با نقش content | موفق؛ مسیر در ردیف gallery ذخیره شود |

### اپ ادمین (نقش content)
| لینک | کار | انتظار |
|------|-----|--------|
| `https://pasteur.plus/admin/login` با content@… | ورود | سایدبار محتوا |
| `/admin/doctors` | لیست از DB | نام‌های seed |
| `/admin/gallery` | افزودن آیتم + آپلود Storage | بدون URL خارجی |
| `/admin/consultation-prices` | قیمت video_gp | ۳۵۰هزار |

### اپ بیمار
| لینک | انتظار |
|------|--------|
| `/dental` یا `/app/dental` | پزشکان/خدمات از API/DB |
| `/gallery` | تصاویر از signed URL یا مسیر Storage پروژه |

## Seed داده فیک
- پزشکان و خدمات در `03_seed.sql`
- تصویر: فایل محلی → Storage؛ مسیر مثل `gallery/{uuid}.png`

## معیار Done
- [ ] بدون CDN خارجی
- [ ] نقش ops نتواند گالری را ویرایش کند
- [ ] UI ظاهر ثابت
