# TODO v3 — فاز ۳: بیمار، بیمه/فرانشیز، رزرو، مشاوره، یادآور

## ترتیب SQL — `backend/phase-03-patient-ops/`
1. [ ] `01_schema.sql`
2. [ ] `02_rls_policies.sql`
3. [ ] `03_seed.sql`

## چک‌لیست
- [ ] `patient_profiles.franchise_percent` (نه تومان)
- [ ] استعلام بیمه + تأیید ادمین
- [ ] bookings / consultations / reminders
- [ ] گیت: تا `profiles.status != approved` اعمال٪ روی ویزیت نشود (منطق اپ)

## تست سرور

### بیمار
| لینک | داده فیک | انتظار |
|------|----------|--------|
| `/account` یا `/app/account` با patient1@… | فرانشیز ۱۰٪، بیمه دانا | ذخیره؛ وضعیت در حال بررسی تا تأیید |
| `/consultation` | ویزیت ۳۵۰هزار + تیک تکمیلی پس از تأیید | مبلغ واریزی ۳۵هزار |

### ادمین
| نقش | لینک | کار | انتظار |
|-----|------|-----|--------|
| finance یا admin | `/admin/patients` | تأیید patient1 | status=approved |
| finance/admin | `/admin/insurances` | تأیید استعلام pending | status=approved؛ payable=35000 |
| ops | `/admin/bookings` | رزرو نمونه | ردیف در جدول |
| ops | `/admin/consultations` | مشاهده درخواست | ردیف seed/ثبت‌شده |
| ops | `/admin/reminders` | یادآور | قابل ایجاد |

### Supabase
| مسیر | انتظار |
|------|--------|
| Table Editor → `insurance_companies` | پایه + تکمیلی seed |
| `patient_profiles` برای patient1 | franchise_percent=10 |
| `insurance_inquiries` | pending یا approved پس از تست |

## معیار Done
- [ ] ۱۰٪ از ۳۵۰هزار = ۳۵هزار در داده
- [ ] ops به patients دسترسی ندارد مگر permission داده شود
- [ ] UI ثابت
