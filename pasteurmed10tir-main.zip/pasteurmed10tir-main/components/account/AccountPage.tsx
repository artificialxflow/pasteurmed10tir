"use client";

import { AccountDashboard } from "@/components/account/AccountDashboard";
import { Button } from "@/components/ui/Button";
import { Card, FormInput, FormLabel, FormSelect } from "@/components/ui/Card";
import { notifyPatientAuthChanged } from "@/lib/auth/use-patient-profile";
import { fetchPublic } from "@/lib/content/client";
import { ROUTES } from "@/lib/routes";
import { PasteurStorage } from "@/lib/storage";
import {
  clampFranchisePercent,
  DEFAULT_FRANCHISE_PERCENT,
  DEFAULT_VISIT_FEE_TOMAN,
  isPatientApproved,
  patientStatusLabel,
  payableFromFranchise,
  type InsuranceCompany,
  type PatientProfile,
} from "@/lib/patient";
import { WEB_PAGE_CONTAINER } from "@/lib/layout";
import { formatPrice, normalizePhone } from "@/lib/utils";
import Link from "next/link";
import { FormEvent, useCallback, useEffect, useState } from "react";

export function AccountPage({ variant = "web" }: { variant?: "web" | "app" }) {
  const [profile, setProfile] = useState<PatientProfile | null>(null);
  const [phone, setPhone] = useState("");
  const [name, setName] = useState("");
  const [otpCode, setOtpCode] = useState("");
  const [nationalId, setNationalId] = useState("");
  const [baseId, setBaseId] = useState("");
  const [compId, setCompId] = useState("");
  const [franchise, setFranchise] = useState(String(DEFAULT_FRANCHISE_PERCENT));
  const [message, setMessage] = useState("");
  const [ready, setReady] = useState(false);
  const [sendingOtp, setSendingOtp] = useState(false);
  const [otpSent, setOtpSent] = useState(false);
  const [registered, setRegistered] = useState(false);
  const [baseList, setBaseList] = useState<InsuranceCompany[]>([]);
  const [compList, setCompList] = useState<InsuranceCompany[]>([]);
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);

  const hydrate = useCallback((p: PatientProfile) => {
    setProfile(p);
    setPhone(p.phone);
    setName(p.name);
    setNationalId(p.nationalId || "");
    setBaseId(p.baseInsuranceId || "");
    setCompId(p.complementaryInsuranceId || "");
    setFranchise(String(p.franchisePercent ?? DEFAULT_FRANCHISE_PERCENT));
    if (p.status === "approved") setEditing(false);
  }, []);

  useEffect(() => {
    PasteurStorage.hideMembershipInstallmentPlans();

    fetchPublic<{ base: InsuranceCompany[]; complementary: InsuranceCompany[] }>(
      "/api/content/insurances",
    )
      .then((data) => {
        setBaseList(data.base.filter((i) => i.active !== false));
        setCompList(data.complementary.filter((i) => i.active !== false));
      })
      .catch(() => {});

    fetch("/api/auth/me", { credentials: "include" })
      .then(async (res) => {
        if (!res.ok) return null;
        const data = (await res.json()) as { profile?: PatientProfile };
        return data.profile ?? null;
      })
      .then((p) => {
        if (p) hydrate(p);
      })
      .finally(() => setReady(true));
  }, [hydrate]);

  async function sendOtp() {
    const digits = normalizePhone(phone);
    if (digits.length < 10) {
      setMessage("موبایل معتبر وارد کنید.");
      return;
    }
    setSendingOtp(true);
    setMessage("");
    try {
      const res = await fetch("/api/auth/otp/send", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone: digits }),
      });
      const data = (await res.json()) as {
        error?: string;
        message?: string;
        mode?: string;
        registered?: boolean;
      };
      if (!res.ok) {
        setMessage(data.error || "ارسال کد ناموفق بود.");
        setOtpSent(false);
        return;
      }
      setOtpSent(true);
      setRegistered(Boolean(data.registered));
      setMessage(
        data.registered
          ? "حساب از قبل وجود دارد. کد را وارد کنید و وارد شوید."
          : data.message || "کد ارسال شد. برای ثبت‌نام نام را هم وارد کنید.",
      );
    } catch {
      setMessage("خطا در ارتباط با سرور.");
    } finally {
      setSendingOtp(false);
    }
  }

  async function login(e: FormEvent) {
    e.preventDefault();
    const digits = normalizePhone(phone);
    if (digits.length < 10 || !otpCode.trim()) {
      setMessage("موبایل و کد تأیید را وارد کنید.");
      return;
    }
    if (!registered && !name.trim()) {
      setMessage("برای ثبت‌نام، نام و نام خانوادگی را وارد کنید.");
      return;
    }
    setMessage("");
    try {
      const res = await fetch("/api/auth/otp/verify", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          phone: digits,
          code: otpCode.trim(),
          ...(registered ? {} : { name: name.trim() }),
        }),
      });
      const data = (await res.json()) as { profile?: PatientProfile; error?: string };
      if (!res.ok || !data.profile) {
        setMessage(data.error || "ورود ناموفق بود.");
        return;
      }
      hydrate(data.profile);
      notifyPatientAuthChanged();
      if (data.profile.status !== "approved") setEditing(true);
      setMessage(
        data.profile.status === "approved"
          ? "وارد شدید. پروفایل شما فعال است."
          : "وارد شدید. حساب در سامانه ثبت شد — کارشناس در «تأیید کاربری» ادمین بررسی می‌کند.",
      );
    } catch {
      setMessage("خطا در ارتباط با سرور.");
    }
  }

  async function save(e: FormEvent) {
    e.preventDefault();
    if (!profile) return;
    const nid = nationalId.trim();
    if (!nid) {
      setMessage("کد ملی الزامی است.");
      return;
    }
    const percent = clampFranchisePercent(Number(franchise));
    setMessage("");
    setSaving(true);
    try {
      const res = await fetch("/api/auth/profile", {
        method: "PATCH",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: name.trim(),
          nationalId: nid,
          baseInsuranceId: baseId || undefined,
          complementaryInsuranceId: compId || undefined,
          franchisePercent: percent,
        }),
      });
      const data = (await res.json()) as { profile?: PatientProfile; error?: string };
      if (!res.ok || !data.profile) {
        setMessage(data.error || "ذخیره ناموفق بود.");
        return;
      }
      hydrate(data.profile);
      notifyPatientAuthChanged();
      if (data.profile.status === "approved") {
        setEditing(false);
        setMessage(
          data.profile.zohalStatus === "passed"
            ? "پروفایل ذخیره شد. استعلام شاهکار موفق — حساب شما تأیید شد."
            : "پروفایل ذخیره شد و تأیید شد.",
        );
      } else if (data.profile.status === "rejected") {
        setEditing(true);
        setMessage(
          data.profile.zohalStatus === "failed"
            ? "کد ملی با موبایل شما تطبیق ندارد. کد ملی را اصلاح کنید و دوباره ذخیره کنید."
            : data.profile.reviewNote || "درخواست رد شد. مشخصات را اصلاح کنید.",
        );
      } else if (data.profile.zohalStatus === "error") {
        setEditing(true);
        setMessage(
          "پروفایل ذخیره شد. خطا در استعلام زحل — کارشناس به‌صورت دستی بررسی می‌کند.",
        );
      } else {
        setEditing(true);
        setMessage(
          data.profile.zohalStatus === "skipped"
            ? "پروفایل ذخیره شد و برای بررسی کارشناس در صف قرار گرفت."
            : "پروفایل ذخیره شد. در حال بررسی…",
        );
      }
    } catch {
      setMessage("خطا در ارتباط با سرور.");
    } finally {
      setSaving(false);
    }
  }

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST", credentials: "include" });
    setProfile(null);
    setOtpCode("");
    setOtpSent(false);
    notifyPatientAuthChanged();
    setMessage("خارج شدید.");
  }

  if (!ready) {
    return <p className="py-10 text-center text-sm text-slate-500">در حال بارگذاری...</p>;
  }

  const helpHref = variant === "app" ? ROUTES.app.help : ROUTES.web.help;
  const complaintsHref = variant === "app" ? ROUTES.app.complaints : ROUTES.web.complaints;
  const supportHref = variant === "app" ? ROUTES.app.support : ROUTES.web.support;
  const installmentsHref =
    variant === "app" ? ROUTES.app.installments : ROUTES.web.installments;

  if (!profile) {
    return (
      <div className={variant === "app" ? "space-y-4" : WEB_PAGE_CONTAINER}>
        <h1 className="mb-2 text-xl font-extrabold text-slate-900">ورود به پنل کاربری</h1>
        <p className="mb-6 text-sm text-slate-600">
          اگر از قبل ثبت‌نام کرده‌اید فقط موبایل و کد کافی است. نام فقط برای ثبت‌نام اول لازم است.
        </p>
        <Card hover={false} className="mb-4 border-cyan-100 bg-cyan-50/60 p-4 text-xs leading-6 text-slate-600">
          <p className="font-bold text-slate-800">مراحل</p>
          <ol className="mt-2 list-decimal space-y-1 pr-4">
            <li>موبایل را وارد کنید و «دریافت کد» بزنید</li>
            <li>اگر حساب جدید باشد، نام و نام خانوادگی را بنویسید</li>
            <li>کد را وارد کنید و «ورود به پنل کاربری» را بزنید</li>
          </ol>
        </Card>
        <Card hover={false} className="space-y-3 p-5">
          <form onSubmit={login} className="space-y-3">
            <div>
              <FormLabel>موبایل</FormLabel>
              <FormInput
                type="tel"
                value={phone}
                onChange={(e) => {
                  setPhone(e.target.value);
                  setRegistered(false);
                  setOtpSent(false);
                }}
                required
              />
            </div>
            {otpSent && !registered ? (
              <div>
                <FormLabel>نام و نام خانوادگی (ثبت‌نام جدید)</FormLabel>
                <FormInput value={name} onChange={(e) => setName(e.target.value)} required />
              </div>
            ) : null}
            <div>
              <FormLabel>کد تأیید</FormLabel>
              <div className="flex gap-2">
                <FormInput
                  value={otpCode}
                  onChange={(e) => setOtpCode(e.target.value)}
                  placeholder="00000"
                  required
                  className="flex-1"
                />
                <Button
                  type="button"
                  variant="outline"
                  className="shrink-0 text-sm"
                  disabled={sendingOtp}
                  onClick={sendOtp}
                >
                  {sendingOtp ? "..." : "دریافت کد"}
                </Button>
              </div>
            </div>
            {message ? (
              <p
                className={`text-sm font-bold ${otpSent && !profile ? "text-teal-800" : "text-cyan-800"}`}
              >
                {message}
              </p>
            ) : null}
            {otpSent && !profile ? (
              <p className="text-xs font-bold text-amber-800">
                حالا کد را وارد کنید و دکمه «ورود به پنل کاربری» را بزنید.
              </p>
            ) : null}
            <Button type="submit" className="w-full">
              ورود به پنل کاربری
            </Button>
          </form>
        </Card>
      </div>
    );
  }

  const samplePayable = payableFromFranchise(
    DEFAULT_VISIT_FEE_TOMAN,
    clampFranchisePercent(Number(franchise)),
  );
  const approved = isPatientApproved(profile);
  const showDashboard = approved && !editing;

  return (
    <div className={variant === "app" ? "space-y-4" : `${WEB_PAGE_CONTAINER} space-y-6`}>
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-xl font-extrabold text-slate-900">
            {showDashboard ? "پنل من" : editing && approved ? "ویرایش مشخصات" : "پنل کاربری"}
          </h1>
          <p className="mt-1 text-sm text-slate-500">{profile.phone}</p>
          <p
            className={`mt-2 text-sm font-bold ${
              approved ? "text-teal-700" : "text-amber-700"
            }`}
          >
            وضعیت کاربری: {patientStatusLabel(profile.status)}
          </p>
        </div>
        <Button type="button" variant="outline" className="text-sm" onClick={logout}>
          خروج
        </Button>
      </div>

      {!approved ? (
        <Card hover={false} className="border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">
          {profile.status === "rejected" ? (
            <>
              درخواست قبلی رد شده است. مشخصات را اصلاح کنید و دوباره ذخیره کنید تا کارشناس
              بررسی کند.
              {profile.zohalStatus === "failed" ? (
                <p className="mt-2 font-bold">
                  علت: کد ملی با شماره موبایل {profile.phone} در سامانه شاهکار تطبیق ندارد.
                </p>
              ) : null}
              {profile.reviewNote ? (
                <p className="mt-2 font-bold">یادداشت کارشناس: {profile.reviewNote}</p>
              ) : null}
            </>
          ) : (
            <>
              حساب شما ثبت شده است.
              {profile.zohalStatus === "error" ? (
                <> خطا در استعلام خودکار — کارشناس به‌صورت دستی بررسی می‌کند.</>
              ) : profile.zohalStatus === "skipped" ? (
                <> در لیست «تأیید کاربری» ادمین قرار دارد.</>
              ) : (
                <> استعلام شاهکار در حال انجام یا بررسی است.</>
              )}
            </>
          )}
        </Card>
      ) : showDashboard ? null : (
        <Card hover={false} className="border-cyan-100 bg-cyan-50/60 p-4 text-sm text-slate-700">
          در حال ویرایش مشخصات. اگر بیمه یا فرانشیز را تغییر دهید، حساب دوباره برای بررسی کارشناس
          در صف قرار می‌گیرد.
        </Card>
      )}

      {showDashboard ? (
        <AccountDashboard
          profile={profile}
          variant={variant}
          message={message}
          onEditProfile={() => {
            setEditing(true);
            setMessage("");
          }}
        />
      ) : (
        <>
          <div className="grid gap-2 sm:grid-cols-2">
            <Link
              href={installmentsHref}
              className="rounded-xl border border-teal-200 bg-teal-50/80 px-4 py-3 text-sm font-extrabold text-teal-900 transition hover:border-teal-400"
            >
              اقساط من
              <span className="mt-0.5 block text-xs font-normal text-teal-800/80">
                صورتحساب و پرداخت قسط
              </span>
            </Link>
            <Link
              href={supportHref}
              className="rounded-xl border border-cyan-200 bg-cyan-50/80 px-4 py-3 text-sm font-extrabold text-cyan-900 transition hover:border-cyan-400"
            >
              پشتیبانی / تیکت
              <span className="mt-0.5 block text-xs font-normal text-cyan-800/80">
                ثبت درخواست و پیگیری پاسخ
              </span>
            </Link>
            <Link
              href={helpHref}
              className="rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-bold text-slate-800 transition hover:border-slate-300"
            >
              آموزش سامانه
            </Link>
            <Link
              href={complaintsHref}
              className="rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-bold text-slate-800 transition hover:border-slate-300"
            >
              ثبت شکایت
            </Link>
          </div>

          <Card hover={false} className="p-5">
            <form onSubmit={save} className="grid gap-3 sm:grid-cols-2">
              <div className="sm:col-span-2">
                <FormLabel>نام</FormLabel>
                <FormInput value={name} onChange={(e) => setName(e.target.value)} required />
              </div>
              <div>
                <FormLabel>کد ملی</FormLabel>
                <FormInput
                  value={nationalId}
                  onChange={(e) => setNationalId(e.target.value)}
                  required
                  inputMode="numeric"
                  maxLength={10}
                  placeholder="۱۰ رقم"
                />
              </div>
              <div>
                <FormLabel>فرانشیز (درصد)</FormLabel>
                <FormInput
                  type="number"
                  min={0}
                  max={100}
                  value={franchise}
                  onChange={(e) => setFranchise(e.target.value)}
                />
              </div>
              <div>
                <FormLabel>بیمه پایه</FormLabel>
                <FormSelect value={baseId} onChange={(e) => setBaseId(e.target.value)}>
                  <option value="">— انتخاب کنید —</option>
                  {baseList.map((i) => (
                    <option key={i.id} value={i.id}>
                      {i.name}
                    </option>
                  ))}
                </FormSelect>
              </div>
              <div>
                <FormLabel>بیمه تکمیلی</FormLabel>
                <FormSelect value={compId} onChange={(e) => setCompId(e.target.value)}>
                  <option value="">— انتخاب کنید —</option>
                  {compList.map((i) => (
                    <option key={i.id} value={i.id}>
                      {i.name}
                    </option>
                  ))}
                </FormSelect>
              </div>
              <div className="sm:col-span-2">
                <p className="mb-3 text-xs leading-6 text-slate-500">
                  پس از تأیید کارشناس، فقط همین درصد از هزینه ویزیت پرداخت می‌شود. مثال: ویزیت{" "}
                  {formatPrice(DEFAULT_VISIT_FEE_TOMAN)} با فرانشیز{" "}
                  {clampFranchisePercent(Number(franchise))}٪ → مبلغ واریزی{" "}
                  {formatPrice(samplePayable)}.
                </p>
                {message ? <p className="mb-3 text-sm font-bold text-cyan-800">{message}</p> : null}
                <div className="flex flex-wrap gap-2">
                  <Button type="submit" disabled={saving}>
                    {saving ? "در حال ذخیره و استعلام…" : "ذخیره مشخصات"}
                  </Button>
                  {approved ? (
                    <Button
                      type="button"
                      variant="ghost"
                      onClick={() => {
                        hydrate(profile);
                        setMessage("");
                        setEditing(false);
                      }}
                    >
                      بازگشت به پنل
                    </Button>
                  ) : null}
                </div>
              </div>
            </form>
          </Card>
        </>
      )}
    </div>
  );
}
