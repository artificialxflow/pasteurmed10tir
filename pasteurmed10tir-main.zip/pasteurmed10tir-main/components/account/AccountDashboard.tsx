"use client";

import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";
import { AssignedStaffCard } from "@/components/home-visit/AssignedStaffCard";
import { AccountAccordionSection } from "@/components/account/AccountAccordionSection";
import { DependentsCard } from "@/components/account/DependentsCard";
import { FieldStaffAvailabilityCard } from "@/components/account/FieldStaffAvailabilityCard";
import { FieldStaffCommissionsCard } from "@/components/account/FieldStaffCommissionsCard";
import { FieldStaffJobsCard } from "@/components/account/FieldStaffJobsCard";
import { LoanRequestCard } from "@/components/account/LoanRequestCard";
import { fetchPublic } from "@/lib/content/client";
import { fetchMyActivityApi, patchPatientOps } from "@/lib/operations/client";
import {
  bookingStatusLabel,
  DEFAULT_VISIT_FEE_TOMAN,
  insuranceInquiryStatusLabel,
  isPatientApproved,
  patientStatusLabel,
  payableFromFranchise,
  resolveFranchisePercent,
  shopOrderStatusLabel,
  type InsuranceCompany,
  type PatientProfile,
} from "@/lib/patient";
import { ROUTES } from "@/lib/routes";
import { formatPrice } from "@/lib/utils";
import { zohalStatusLabel } from "@/lib/zohal/patient-verify";
import Link from "next/link";
import { useEffect, useMemo, useState } from "react";

function insuranceName(list: InsuranceCompany[], id?: string): string {
  if (!id) return "—";
  return list.find((i) => i.id === id)?.name || id;
}

function StatusBadge({
  label,
  value,
  tone,
}: {
  label: string;
  value: string;
  tone: "success" | "warn" | "danger" | "info";
}) {
  const tones = {
    success: "border-teal-200 bg-teal-50 text-teal-900",
    warn: "border-amber-200 bg-amber-50 text-amber-900",
    danger: "border-rose-200 bg-rose-50 text-rose-900",
    info: "border-cyan-200 bg-cyan-50 text-cyan-900",
  };
  return (
    <div className={`rounded-xl border p-3 ${tones[tone]}`}>
      <p className="text-xs font-bold opacity-80">{label}</p>
      <p className="mt-1 text-sm font-extrabold">{value}</p>
    </div>
  );
}

function ActivityRow({
  title,
  meta,
  status,
  tone,
}: {
  title: string;
  meta: string;
  status: string;
  tone: "success" | "warn" | "danger" | "info";
}) {
  const badgeTone = {
    success: "text-teal-700",
    warn: "text-amber-700",
    danger: "text-rose-700",
    info: "text-cyan-800",
  };
  return (
    <div className="flex flex-wrap items-start justify-between gap-2 border-b border-slate-100 py-3 last:border-0">
      <div>
        <p className="text-sm font-bold text-slate-900">{title}</p>
        <p className="mt-0.5 text-xs text-slate-500">{meta}</p>
      </div>
      <span className={`text-xs font-bold ${badgeTone[tone]}`}>{status}</span>
    </div>
  );
}

export function AccountDashboard({
  profile,
  variant,
  onEditProfile,
  message,
}: {
  profile: PatientProfile;
  variant: "web" | "app";
  onEditProfile: () => void;
  message?: string;
}) {
  const [baseList, setBaseList] = useState<InsuranceCompany[]>([]);
  const [compList, setCompList] = useState<InsuranceCompany[]>([]);
  const [activity, setActivity] = useState<Awaited<ReturnType<typeof fetchMyActivityApi>> | null>(
    null,
  );
  const [activityError, setActivityError] = useState("");
  const [cancelBusy, setCancelBusy] = useState<string | null>(null);
  const [cancelMessage, setCancelMessage] = useState("");

  const dentalHref = variant === "app" ? ROUTES.app.dentalGeneral : ROUTES.web.dentalGeneral;
  const consultationHref = variant === "app" ? ROUTES.app.consultation : ROUTES.web.consultation;
  const shopHref = variant === "app" ? ROUTES.app.shop : ROUTES.web.shop;
  const clubHref = variant === "app" ? ROUTES.app.club : ROUTES.web.club;
  const installmentsHref =
    variant === "app" ? ROUTES.app.installments : ROUTES.web.installments;
  const helpHref = variant === "app" ? ROUTES.app.help : ROUTES.web.help;
  const supportHref = variant === "app" ? ROUTES.app.support : ROUTES.web.support;
  const complaintsHref = variant === "app" ? ROUTES.app.complaints : ROUTES.web.complaints;
  const healthHref = variant === "app" ? ROUTES.app.healthRecord : ROUTES.web.healthRecord;

  useEffect(() => {
    void fetchPublic<{ base: InsuranceCompany[]; complementary: InsuranceCompany[] }>(
      "/api/content/insurances",
    )
      .then((data) => {
        setBaseList(data.base.filter((i) => i.active !== false));
        setCompList(data.complementary.filter((i) => i.active !== false));
      })
      .catch(() => {});

    void fetchMyActivityApi()
      .then(setActivity)
      .catch((e) => setActivityError(e instanceof Error ? e.message : "خطا در بارگذاری"));
  }, []);

  const franchisePercent = resolveFranchisePercent(profile);
  const lastInquiry = activity?.insuranceInquiries?.[0];
  const hasInsuranceRegistered = Boolean(
    profile.baseInsuranceId || profile.complementaryInsuranceId,
  );

  const inquiryBadge = useMemo(() => {
    if (!lastInquiry) {
      return { label: "استعلام بیمه", value: "هنوز ثبت نشده", tone: "info" as const };
    }
    const st = String(lastInquiry.status || "");
    if (st === "approved") {
      return { label: "استعلام بیمه", value: "پوشش تأیید شد", tone: "success" as const };
    }
    if (st === "rejected") {
      return { label: "استعلام بیمه", value: "رد شده", tone: "danger" as const };
    }
    return { label: "استعلام بیمه", value: "در انتظار تأیید بیمه", tone: "warn" as const };
  }, [lastInquiry]);

  const lastBooking = activity?.bookings?.[0];
  const bookingBadge = useMemo(() => {
    if (!lastBooking) {
      return { label: "آخرین نوبت", value: "رزروی ثبت نشده", tone: "info" as const };
    }
    const label = bookingStatusLabel(String(lastBooking.status || ""));
    const st = String(lastBooking.status || "");
    const tone =
      st === "confirmed" ? ("success" as const) : st === "cancelled" ? ("danger" as const) : ("warn" as const);
    return { label: "آخرین نوبت", value: label, tone };
  }, [lastBooking]);

  const shahkarTone =
    profile.zohalStatus === "passed" || profile.shahkarMatched === true
      ? "success"
      : profile.zohalStatus === "failed" || profile.shahkarMatched === false
        ? "danger"
        : "warn";

  const userTone = isPatientApproved(profile)
    ? "success"
    : profile.status === "rejected"
      ? "danger"
      : "warn";

  function reloadActivity() {
    void fetchMyActivityApi()
      .then(setActivity)
      .catch((e) => setActivityError(e instanceof Error ? e.message : "خطا در بارگذاری"));
  }

  function cancelBooking(id: string) {
    if (
      !window.confirm(
        "آیا از لغو این نوبت مطمئن هستید؟\n\nبیعانه پرداخت‌شده قابل استرداد نیست.",
      )
    ) {
      return;
    }
    setCancelBusy(id);
    setCancelMessage("");
    void patchPatientOps<{ message?: string }>(`/api/operations/bookings/${encodeURIComponent(id)}`, {
      status: "cancelled",
    })
      .then((res) => {
        setCancelMessage(res.message || "رزرو لغو شد.");
        reloadActivity();
      })
      .catch((e) => setCancelMessage(e instanceof Error ? e.message : "لغو ناموفق"))
      .finally(() => setCancelBusy(null));
  }

  return (
    <div
      className={
        variant === "web"
          ? "grid items-start gap-6 lg:grid-cols-[15.5rem_minmax(0,1fr)]"
          : ""
      }
    >
      {variant === "web" ? (
        <aside className="hidden lg:sticky lg:top-28 lg:block">
          <nav className="space-y-1 rounded-2xl border border-sky-200 bg-white p-3 text-sm shadow-sm">
            <p className="mb-2 px-2 text-xs font-extrabold text-slate-500">خلاصه فعالیت</p>
            {[
              { href: dentalHref, label: "رزرو نوبت دندان" },
              { href: healthHref, label: "پرونده سلامت" },
              { href: installmentsHref, label: "اقساط من" },
              { href: shopHref, label: "فروشگاه" },
              { href: clubHref, label: "باشگاه" },
              { href: supportHref, label: "پشتیبانی" },
              { href: helpHref, label: "آموزش سامانه" },
              { href: complaintsHref, label: "شکایات" },
            ].map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="block rounded-xl border border-transparent px-3 py-2 font-bold text-slate-700 hover:border-cyan-200 hover:bg-cyan-50"
              >
                {item.label}
              </Link>
            ))}
            <button
              type="button"
              onClick={onEditProfile}
              className="block w-full rounded-xl px-3 py-2 text-right font-bold text-slate-700 hover:bg-slate-50"
            >
              ویرایش مشخصات
            </button>
          </nav>
        </aside>
      ) : null}
      <div className="min-w-0 space-y-6">
      <Card hover={false} className="border-teal-200 bg-teal-50/50 p-4 text-sm text-teal-900">
        سلام {profile.name.split(/\s+/)[0] || "بیمار"} — پنل شما فعال است. برای رزرو دیگر نیازی به
        وارد کردن دوباره نام و موبایل نیست.
      </Card>

      <Card hover={false} className="p-4" data-account-section="profile">
        <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
          <p className="text-sm font-extrabold text-slate-900">مشخصات ثبت‌شده</p>
          <Button type="button" variant="outline" className="text-xs" onClick={onEditProfile}>
            ویرایش مشخصات
          </Button>
        </div>
        <div className="grid gap-2 text-sm sm:grid-cols-2">
          <p>
            <span className="text-slate-500">نام:</span>{" "}
            <span className="font-bold">{profile.name}</span>
          </p>
          <p>
            <span className="text-slate-500">موبایل:</span>{" "}
            <span className="font-bold font-mono text-xs">{profile.phone}</span>
          </p>
          <p>
            <span className="text-slate-500">کد ملی:</span>{" "}
            <span className="font-bold font-mono text-xs">{profile.nationalId || "—"}</span>
          </p>
          {profile.fileNumber ? (
            <p>
              <span className="text-slate-500">شماره پرونده:</span>{" "}
              <span className="font-bold font-mono text-xs">{profile.fileNumber}</span>
            </p>
          ) : null}
          <p>
            <span className="text-slate-500">فرانشیز:</span>{" "}
            <span className="font-bold">{franchisePercent}٪</span>
          </p>
        </div>
        <p className="mt-3 text-xs leading-6 text-slate-500">
          نمونه ویزیت {formatPrice(DEFAULT_VISIT_FEE_TOMAN)} با فرانشیز {franchisePercent}٪ →{" "}
          <strong className="text-teal-800">
            {formatPrice(payableFromFranchise(DEFAULT_VISIT_FEE_TOMAN, franchisePercent))}
          </strong>
          . «تأیید استعلام رزرو» جدا از پروفایل است و در مرحله پرداخت رزرو انجام می‌شود.
        </p>
      </Card>

      <div data-account-section="dependents">
        <DependentsCard />
      </div>

      <Card
        hover={false}
        className="border-dashed border-slate-300 bg-slate-50/80 p-4"
        data-account-section="health-record"
      >
        <p className="text-sm font-extrabold text-slate-900">پرونده سلامت</p>
        <p className="mt-1 text-xs leading-6 text-slate-600">
          ثبت علائم، یادداشت تخصصی و بارگذاری مدارک (jpg، pdf) — گزارش کلی پرونده هم از همان بخش در دسترس است.
        </p>
        <div className="mt-3 flex flex-wrap gap-2">
          <Link
            href={healthHref}
            className="inline-flex rounded-xl border border-teal-600 bg-teal-50 px-3 py-2 text-xs font-bold text-teal-800"
          >
            ورود به پرونده سلامت
          </Link>
          <Link
            href={variant === "app" ? ROUTES.app.healthRecordReport : ROUTES.web.healthRecordReport}
            className="inline-flex rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs font-bold text-slate-700"
          >
            گزارش کلی
          </Link>
        </div>
      </Card>

      <FieldStaffAvailabilityCard />
      <FieldStaffCommissionsCard />
      <FieldStaffJobsCard />

      <p className="text-xs leading-6 text-slate-500">
        توجه: <strong>تأیید نوبت</strong> در ادمین رزروها جدا از <strong>تأیید استعلام بیمه</strong> است.
        وضعیت نوبت و بیمه را در کارت‌های زیر جدا ببینید.
      </p>

      <div className="grid gap-3 sm:grid-cols-2">
        <StatusBadge
          label="کاربری"
          value={patientStatusLabel(profile.status)}
          tone={userTone}
        />
        <StatusBadge
          label="کد ملی (شاهکار)"
          value={zohalStatusLabel(profile.zohalStatus, profile.shahkarMatched)}
          tone={shahkarTone}
        />
        <StatusBadge
          label="بیمه ثبت‌شده"
          value={
            hasInsuranceRegistered
              ? `${insuranceName(compList, profile.complementaryInsuranceId) !== "—" ? insuranceName(compList, profile.complementaryInsuranceId) : insuranceName(baseList, profile.baseInsuranceId)} · ${franchisePercent}٪`
              : "ثبت نشده"
          }
          tone={hasInsuranceRegistered ? "info" : "warn"}
        />
        <StatusBadge label={bookingBadge.label} value={bookingBadge.value} tone={bookingBadge.tone} />
        <StatusBadge label={inquiryBadge.label} value={inquiryBadge.value} tone={inquiryBadge.tone} />
      </div>

      <Card hover={false} className="p-4">
        <p className="mb-3 text-sm font-extrabold text-slate-900">دسترسی سریع</p>
        <div className="flex flex-wrap gap-2">
          <Link href={dentalHref}>
            <Button type="button" className="text-sm">
              رزرو نوبت دندان
            </Button>
          </Link>
          <Link href={consultationHref}>
            <Button type="button" variant="outline" className="text-sm">
              مشاوره
            </Button>
          </Link>
          <Link href={shopHref}>
            <Button type="button" variant="outline" className="text-sm">
              فروشگاه
            </Button>
          </Link>
          <Link href={clubHref}>
            <Button type="button" variant="outline" className="text-sm">
              باشگاه
            </Button>
          </Link>
          <Link href={installmentsHref}>
            <Button type="button" variant="outline" className="text-sm">
              اقساط
            </Button>
          </Link>
        </div>
      </Card>

      <div className="space-y-3" data-account-section="finance-accordion">
        <AccountAccordionSection
          title="درخواست وام / اعتبار"
          summary="فرم درخواست وام و اعتبار — فقط در صورت نیاز باز کنید"
        >
          <LoanRequestCard
            phone={profile.phone}
            name={profile.name}
            nationalId={profile.nationalId}
            variant={variant}
          />
        </AccountAccordionSection>

        <AccountAccordionSection
          title="اقساط"
          summary="پیگیری طرح‌های اقساطی و جدول بازپرداخت"
        >
          <p className="mb-3 text-xs leading-6 text-slate-600">
            جزئیات قسط‌ها، سررسید و وضعیت پرداخت در صفحه اقساط حساب شماست.
          </p>
          <Link href={installmentsHref}>
            <Button type="button" className="text-sm">
              مشاهده اقساط
            </Button>
          </Link>
        </AccountAccordionSection>

        <AccountAccordionSection
          title="بیمه"
          summary={
            hasInsuranceRegistered
              ? `ثبت‌شده · فرانشیز ${franchisePercent}٪`
              : "هنوز بیمه‌ای در پروفایل ثبت نشده"
          }
        >
          <div className="space-y-3 text-sm">
            <p>
              <span className="text-slate-500">پایه:</span>{" "}
              <span className="font-bold">{insuranceName(baseList, profile.baseInsuranceId)}</span>
            </p>
            <p>
              <span className="text-slate-500">تکمیلی:</span>{" "}
              <span className="font-bold">
                {insuranceName(compList, profile.complementaryInsuranceId)}
              </span>
            </p>
            <p>
              <span className="text-slate-500">فرانشیز:</span>{" "}
              <span className="font-bold">{franchisePercent}٪</span>
            </p>
            <Button type="button" variant="outline" className="text-xs" onClick={onEditProfile}>
              ویرایش بیمه در مشخصات
            </Button>
            <div className="border-t border-slate-100 pt-3">
              <p className="mb-2 text-sm font-extrabold text-slate-900">استعلام‌های بیمه (رزرو)</p>
              {!activity ? (
                <p className="text-xs text-slate-500">در حال بارگذاری…</p>
              ) : activity.insuranceInquiries.length === 0 ? (
                <p className="text-xs text-slate-500">
                  استعلامی ثبت نشده. در صفحه تأیید رزرو (`/dental/confirm`) درخواست دهید.
                </p>
              ) : (
                activity.insuranceInquiries.map((q) => {
                  const st = String(q.status || "");
                  const tone =
                    st === "approved" ? "success" : st === "rejected" ? "danger" : "warn";
                  const visitFee = Number(q.visitFee) || DEFAULT_VISIT_FEE_TOMAN;
                  const pct = Number(q.franchisePercent) || franchisePercent;
                  return (
                    <ActivityRow
                      key={String(q.id)}
                      title={`استعلام · ${String(q.mode || "—")}`}
                      meta={`${new Date(String(q.createdAt)).toLocaleDateString("fa-IR")} · فرانشیز ${pct}٪ → ${formatPrice(payableFromFranchise(visitFee, pct))}`}
                      status={insuranceInquiryStatusLabel(st)}
                      tone={tone}
                    />
                  );
                })
              )}
            </div>
          </div>
        </AccountAccordionSection>
      </div>

      {message ? <p className="text-sm font-bold text-cyan-800">{message}</p> : null}
      {cancelMessage ? (
        <p className="text-sm font-bold text-teal-800">{cancelMessage}</p>
      ) : null}

      {activityError ? (
        <p className="text-sm text-rose-600">{activityError}</p>
      ) : !activity ? (
        <p className="text-sm text-slate-500">در حال بارگذاری فعالیت‌ها…</p>
      ) : (
        <div className="space-y-3" data-account-section="activity-accordion">
          <AccountAccordionSection
            title="رزروهای اخیر"
            summary={
              activity.bookings.length === 0
                ? "هنوز رزروی ثبت نشده"
                : `${activity.bookings.length.toLocaleString("fa-IR")} رزرو`
            }
          >
            {activity.bookings.length === 0 ? (
              <p className="text-xs text-slate-500">هنوز رزروی ثبت نشده است.</p>
            ) : (
              activity.bookings.map((b) => {
                const st = String(b.status || "");
                const tone =
                  st === "confirmed" ? "success" : st === "cancelled" ? "danger" : "warn";
                const bookingId = String(b.id);
                return (
                  <div
                    key={bookingId}
                    className="flex flex-wrap items-start justify-between gap-2 border-b border-slate-100 py-3 last:border-0"
                  >
                    <div>
                      <p className="text-sm font-bold text-slate-900">
                        {String(b.doctorName || "رزرو دندانپزشکی")}
                      </p>
                      <p className="mt-0.5 text-xs text-slate-500">
                        {String(b.dateLabel || b.day || "—")} {String(b.timeLabel || "")}
                      </p>
                    </div>
                    <div className="flex flex-col items-end gap-2">
                      <span
                        className={`text-xs font-bold ${
                          tone === "success"
                            ? "text-teal-700"
                            : tone === "danger"
                              ? "text-rose-700"
                              : "text-amber-700"
                        }`}
                      >
                        {bookingStatusLabel(st)}
                      </span>
                      {st !== "cancelled" ? (
                        <Button
                          type="button"
                          variant="outline"
                          className="text-xs text-rose-700"
                          disabled={cancelBusy === bookingId}
                          onClick={() => cancelBooking(bookingId)}
                        >
                          {cancelBusy === bookingId ? "در حال لغو…" : "لغو نوبت"}
                        </Button>
                      ) : null}
                    </div>
                  </div>
                );
              })
            )}
          </AccountAccordionSection>

          <AccountAccordionSection
            title="اعزام خانگی"
            summary={
              (activity.homeVisits || []).length === 0
                ? "درخواستی ثبت نشده"
                : `${(activity.homeVisits || []).length.toLocaleString("fa-IR")} درخواست`
            }
          >
            {(activity.homeVisits || []).length === 0 ? (
              <p className="text-xs text-slate-500">
                درخواست پرستاری یا ویزیت در منزل ثبت نشده است. پس از تخصیص، نام و عکس نیرو اینجا دیده می‌شود.
              </p>
            ) : (
              <div className="grid gap-3 sm:grid-cols-2">
                {(activity.homeVisits || []).map((visit) => {
                  const staff = (visit.assignedStaff as {
                    name?: string;
                    kind?: string;
                    image?: string;
                    specialty?: string;
                  } | null) || null;
                  const href =
                    variant === "app"
                      ? `${ROUTES.app.homeVisitTrack}/${visit.id}`
                      : `${ROUTES.web.homeVisitTrack}/${visit.id}`;
                  return (
                    <Link
                      key={String(visit.id)}
                      href={href}
                      className="block rounded-xl border border-slate-100 p-3 transition hover:border-teal-200 hover:bg-teal-50/40"
                    >
                      <AssignedStaffCard
                        staff={staff}
                        status={String(visit.status || "")}
                        kind={String(visit.kind || "")}
                        serviceTitle={String(visit.serviceTitle || visit.specialtyLabel || "")}
                        areaLabel={String(visit.patientAreaLabel || "")}
                      />
                      {visit.review ? (
                        <p className="mt-2 text-xs text-slate-600">
                          امتیاز شما: {"★".repeat(Number(visit.review.rating) || 0)}
                          {visit.review.status === "pending" ? " · در انتظار تأیید ادمین" : ""}
                        </p>
                      ) : visit.status === "completed" ? (
                        <p className="mt-2 text-xs font-bold text-amber-800">امتیاز هنوز ثبت نشده — از پیگیری ثبت کنید</p>
                      ) : null}
                      <p className="mt-2 text-xs font-bold text-teal-700">مشاهده پیگیری و امتیاز</p>
                    </Link>
                  );
                })}
              </div>
            )}
          </AccountAccordionSection>

          <AccountAccordionSection
            title="مشاوره‌های اخیر"
            summary={
              activity.consultations.length === 0
                ? "درخواستی ثبت نشده"
                : `${activity.consultations.length.toLocaleString("fa-IR")} مشاوره`
            }
          >
            {activity.consultations.length === 0 ? (
              <p className="text-xs text-slate-500">درخواست مشاوره‌ای ثبت نشده است.</p>
            ) : (
              <div className="grid gap-0 sm:grid-cols-2">
                {activity.consultations.map((c) => {
                  const st = String(c.status || "");
                  const tone = st === "answered" ? "success" : "warn";
                  const preferred =
                    c.preferredDateLabel || c.preferredTimeLabel
                      ? ` · ${String(c.preferredDateLabel || "")} ${String(c.preferredTimeLabel || "")}`.trim()
                      : "";
                  return (
                    <ActivityRow
                      key={String(c.id)}
                      title={String(c.typeLabel || c.categoryLabel || "مشاوره")}
                      meta={`${String(c.doctorName || c.specialtyLabel || "—")}${preferred} · ${new Date(String(c.createdAt)).toLocaleDateString("fa-IR")}`}
                      status={st === "answered" ? "پاسخ داده شد" : "در انتظار"}
                      tone={tone}
                    />
                  );
                })}
              </div>
            )}
          </AccountAccordionSection>

          <AccountAccordionSection
            title="سفارشات فروشگاه"
            summary={
              (activity.shopOrders || []).length === 0
                ? "هنوز سفارشی ثبت نشده"
                : `${(activity.shopOrders || []).length.toLocaleString("fa-IR")} سفارش`
            }
          >
            <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
              <p className="text-xs text-slate-500">لیست سفارش‌های اخیر فروشگاه</p>
              <Link href={shopHref} className="text-xs font-bold text-teal-700 hover:underline">
                ادامه خرید
              </Link>
            </div>
            {(activity.shopOrders || []).length === 0 ? (
              <p className="text-xs text-slate-500">هنوز سفارشی از فروشگاه ثبت نشده است.</p>
            ) : (
              <div className="grid gap-0 sm:grid-cols-2">
                {(activity.shopOrders || []).map((order) => {
                  const st = String(order.status || "");
                  const tone =
                    st === "shipped" || st === "confirmed"
                      ? "success"
                      : st === "cancelled"
                        ? "danger"
                        : "warn";
                  const items = Array.isArray(order.items) ? order.items : [];
                  const itemNames = items
                    .slice(0, 2)
                    .map((item) => {
                      const row = item as Record<string, unknown>;
                      return String(row.name || "محصول");
                    })
                    .join("، ");
                  const more = items.length > 2 ? ` و ${items.length - 2} مورد دیگر` : "";
                  return (
                    <ActivityRow
                      key={String(order.id)}
                      title={`${itemNames || "سفارش فروشگاه"}${more}`}
                      meta={`${formatPrice(Number(order.total || 0))} · ${new Date(String(order.createdAt)).toLocaleDateString("fa-IR")} · ${String(order.id)}`}
                      status={shopOrderStatusLabel(st)}
                      tone={tone}
                    />
                  );
                })}
              </div>
            )}
          </AccountAccordionSection>
        </div>
      )}
      </div>
    </div>
  );
}
