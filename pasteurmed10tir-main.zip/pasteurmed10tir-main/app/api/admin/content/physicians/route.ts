import { jsonError, parseJson } from '@/lib/auth/api-utils';
import {
  mapPhysician,
  normalizePhysicianBody,
  type PhysicianBody,
} from '@/lib/content/doctor-mappers';
import { assignIntIds } from '@/lib/content/int-id';
import { requireAdmin } from '@/lib/content/require-admin';
import { prismaRouteError } from '@/lib/prisma/route-error';
import { prisma } from '@/lib/prisma';
import type { Prisma } from '@prisma/client';
import { NextResponse } from 'next/server';

export async function GET() {
  const auth = await requireAdmin('doctors');
  if (auth.error) return auth.error;

  try {
    const items = await prisma.physician.findMany({
      orderBy: [{ sortOrder: 'asc' }, { id: 'asc' }],
    });
    return NextResponse.json({ items: items.map(mapPhysician) });
  } catch (e) {
    return prismaRouteError(e, 'admin/physicians GET');
  }
}

export async function PUT(request: Request) {
  const auth = await requireAdmin('doctors');
  if (auth.error) return auth.error;

  const body = await parseJson<{ items?: PhysicianBody[] }>(request);
  if (!body?.items) return jsonError('درخواست نامعتبر است.');

  const cleaned = assignIntIds(
    body.items
      .map((item) => normalizePhysicianBody(item))
      .filter((item) => item.name),
  );

  try {
    await prisma.$transaction([
      prisma.physician.deleteMany(),
      ...cleaned.map((item, index) =>
        prisma.physician.create({
          data: {
            id: item.id,
            name: item.name,
            specialty: item.specialty,
            specialtyId: item.specialtyId || null,
            medicalCouncilNumber: item.medicalCouncilNumber || '',
            image: item.image,
            days: item.days,
            hours: item.hours || '',
            status: item.status || 'available',
            schedule: (item.schedule || {}) as unknown as Prisma.InputJsonValue,
            sortOrder: index,
            commissionPercent: Math.min(
              100,
              Math.max(0, Math.round(Number(item.commissionPercent ?? 0)) || 0),
            ),
            phone: item.phone || '',
          },
        }),
      ),
    ]);
    return NextResponse.json({ items: cleaned });
  } catch (e) {
    return prismaRouteError(e, 'admin/physicians PUT');
  }
}
